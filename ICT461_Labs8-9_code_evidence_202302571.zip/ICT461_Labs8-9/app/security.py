"""Accounts and server-side sessions (Lab 5). Passwords: Argon2id. Session tokens: random, stored only as SHA-256."""
import hashlib, secrets, sqlite3
from datetime import datetime, timedelta
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, InvalidHashError
from database import get_connection

SESSION_COOKIE = "sessionId"
SESSION_TTL_SECONDS = 3600     # absolute lifetime
SESSION_IDLE_SECONDS = 1800    # idle timeout
_ph = PasswordHasher()
_DUMMY = _ph.hash("dummy-password-for-timing")

def init_security_tables():
    conn = get_connection()
    conn.execute("""CREATE TABLE IF NOT EXISTS users(
        student_id TEXT PRIMARY KEY, full_name TEXT NOT NULL,
        password_hash TEXT NOT NULL, created_at TEXT NOT NULL)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS auth_sessions(
        token_hash TEXT PRIMARY KEY, student_id TEXT NOT NULL,
        created_at TEXT NOT NULL, expires_at TEXT NOT NULL, last_seen TEXT NOT NULL)""")
    conn.commit(); conn.close()

def _h(token): return hashlib.sha256(token.encode()).hexdigest()

def create_user(student_id, full_name, password):
    conn = get_connection()
    try:
        conn.execute("INSERT INTO users VALUES (?,?,?,?)",
                     (student_id, full_name, _ph.hash(password), datetime.now().isoformat()))
        conn.commit(); return True
    except sqlite3.IntegrityError:
        return False
    finally:
        conn.close()

def verify_login(student_id, password):
    conn = get_connection()
    row = conn.execute("SELECT * FROM users WHERE student_id=?", (student_id,)).fetchone()
    conn.close()
    try:
        _ph.verify(row["password_hash"] if row else _DUMMY, password)   # dummy verify: equal timing for unknown users
    except (VerifyMismatchError, InvalidHashError):
        return None
    return {"student_id": row["student_id"], "full_name": row["full_name"]} if row else None

def create_session(student_id):
    token = secrets.token_urlsafe(32)          # new id on every login: prevents session fixation
    now = datetime.now()
    conn = get_connection()
    conn.execute("INSERT INTO auth_sessions VALUES (?,?,?,?,?)",
                 (_h(token), student_id, now.isoformat(),
                  (now + timedelta(seconds=SESSION_TTL_SECONDS)).isoformat(), now.isoformat()))
    conn.commit(); conn.close()
    return token

def get_session_user(token):
    if not token: return None
    conn = get_connection()
    r = conn.execute("""SELECT s.*, u.full_name FROM auth_sessions s JOIN users u USING(student_id)
                        WHERE token_hash=?""", (_h(token),)).fetchone()
    if not r: conn.close(); return None
    now = datetime.now()
    if now > datetime.fromisoformat(r["expires_at"]) or \
       (now - datetime.fromisoformat(r["last_seen"])).total_seconds() > SESSION_IDLE_SECONDS:
        conn.execute("DELETE FROM auth_sessions WHERE token_hash=?", (_h(token),)); conn.commit(); conn.close()
        return None
    conn.execute("UPDATE auth_sessions SET last_seen=? WHERE token_hash=?", (now.isoformat(), _h(token)))
    conn.commit(); conn.close()
    return {"student_id": r["student_id"], "full_name": r["full_name"]}

def destroy_session(token):
    conn = get_connection()
    conn.execute("DELETE FROM auth_sessions WHERE token_hash=?", (_h(token),)); conn.commit(); conn.close()
