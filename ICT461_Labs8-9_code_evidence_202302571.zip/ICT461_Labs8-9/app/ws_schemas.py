"""Lab 8 / Task 2: strict JSON Schema for every frame a client may send (Lab 4 style: additionalProperties false,
bounded lengths, allow-list pattern for free text). Anything else is rejected before it reaches application code."""
from jsonschema import Draft202012Validator

TEXT = {"type": "string", "minLength": 1, "maxLength": 200, "pattern": r"^[A-Za-z0-9 .,!?'()\-:;/@#&%+=_]+$"}
CLIENT_FRAME = {
    "oneOf": [
        {"type": "object", "additionalProperties": False, "required": ["type", "last_id"],
         "properties": {"type": {"const": "sync"}, "last_id": {"type": "integer", "minimum": 0, "maximum": 2**53}}},
        {"type": "object", "additionalProperties": False, "required": ["type", "text"],
         "properties": {"type": {"const": "report"}, "text": TEXT}},
        {"type": "object", "additionalProperties": False, "required": ["type", "text"],
         "properties": {"type": {"const": "announce"}, "text": TEXT}},
    ]
}
_validator = Draft202012Validator(CLIENT_FRAME)

def validate_frame(obj):
    """Return None if valid, otherwise a short, value-free reason (never echo attacker-controlled text back)."""
    errs = list(_validator.iter_errors(obj))
    if not errs: return None
    e = min(errs, key=lambda x: len(list(x.absolute_path)))
    where = ".".join(str(p) for p in e.absolute_path) or "frame"
    return f"{where}: failed '{e.validator}'"
