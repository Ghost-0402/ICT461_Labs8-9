"""Lab 9: delivery performance layer (cache policy, ETag/304, Brotli/gzip compression, hashed-asset helper).
Nothing here changes what the application does; it changes how cheaply the answers travel."""
import gzip, hashlib, json, os, zlib
from flask import request, current_app

try:
    import brotli
except ImportError:          # Brotli is optional; gzip is the fallback
    brotli = None

_HERE = os.path.dirname(os.path.abspath(__file__))
_MANIFEST_PATH = os.path.join(_HERE, "static", "dist", "manifest.json")
COMPRESSIBLE = ("text/html", "text/css", "text/plain", "text/javascript", "application/javascript",
                "application/json", "image/svg+xml", "application/xml", "application/yaml", "text/yaml")
MIN_BYTES = 500
ONE_YEAR = 31536000

# ── 1. Cache-Control policy, one place, one table ─────────────────────────────
IMMUTABLE = f"public, max-age={ONE_YEAR}, immutable"                  # file name contains a content hash
STATIC_REVALIDATE = "public, max-age=3600, stale-while-revalidate=86400"
SHARED_JSON = "public, max-age=0, must-revalidate, s-maxage=5, stale-while-revalidate=30"  # browser revalidates, CDN keeps 5 s
PRIVATE_REVALIDATE = "private, no-cache"
NO_STORE = "private, no-store"

def policy(path, method, status):
    if status >= 400 or method not in ("GET", "HEAD"):
        return NO_STORE
    if path.startswith(("/static/dist/", "/static/img/", "/static/fonts/")):
        # dist/ files are content-hashed; fonts are versioned files that never change in place
        return IMMUTABLE if path.startswith(("/static/dist/", "/static/fonts/")) else STATIC_REVALIDATE
    if path.startswith("/static/"):
        return STATIC_REVALIDATE
    if path in ("/api/occupancy",) or path.startswith("/api/seats/"):
        return SHARED_JSON
    if path == "/api/active_sessions":
        return PRIVATE_REVALIDATE                      # contains an "is this you" flag per caller
    if path in ("/", "/api-docs", "/api/openapi.yaml", "/openapi.yaml"):
        return "public, no-cache"                      # HTML: always revalidate, 304 when unchanged
    return NO_STORE                                    # /admin, /api/admin/*, /portal, auth routes ...

# ── 2. asset('name.js') → hashed URL from the esbuild manifest ───────────────
_manifest = {"mtime": None, "data": {}}
def _load_manifest():
    try:
        mt = os.path.getmtime(_MANIFEST_PATH)
        if mt != _manifest["mtime"]:
            with open(_MANIFEST_PATH, encoding="utf-8") as f: _manifest["data"] = json.load(f)
            _manifest["mtime"] = mt
    except OSError:
        _manifest["data"] = {}
    return _manifest["data"]

def asset(name):
    m = _load_manifest()
    return m.get(name) or ("/static/src/" + name)      # dev fallback if nobody ran the build

# ── 3. Compression ────────────────────────────────────────────────────────────
_cache = {}   # (path, etag, encoding) -> compressed bytes (static files only: compress once, serve many)
def _pick_encoding():
    """Parse Accept-Encoding (with q-values); prefer br, then gzip."""
    accepted = {}
    for part in (request.headers.get("Accept-Encoding") or "").lower().split(","):
        name, _, q = part.strip().partition(";")
        try: accepted[name.strip()] = float(q.split("=")[1]) if "q=" in q else 1.0
        except ValueError: accepted[name.strip()] = 0.0
    if brotli and accepted.get("br", 0) > 0: return "br"
    if accepted.get("gzip", 0) > 0: return "gzip"
    return None

def _compress(data, enc, quality):
    if enc == "br": return brotli.compress(data, quality=quality)
    co = zlib.compressobj(6, zlib.DEFLATED, 31)       # wbits 31 = gzip container
    return co.compress(data) + co.flush()

def init_perf(app):
    app.jinja_env.globals["asset"] = asset
    app.config["SEND_FILE_MAX_AGE_DEFAULT"] = None

    @app.after_request
    def _perf(resp):
        path = request.path
        resp.headers["Cache-Control"] = policy(path, request.method, resp.status_code)
        if path == "/api/active_sessions": resp.headers.add("Vary", "Cookie")   # response depends on the caller's seat cookie
        ctype = (resp.mimetype or "")
        cacheable = resp.status_code == 200 and request.method in ("GET", "HEAD") and not resp.headers.get("Content-Range")
        if not cacheable:
            return resp
        # Work on the body once: ETag first (so it identifies the content, not the encoding), then compress.
        resp.direct_passthrough = False
        body = resp.get_data()
        etag = resp.headers.get("ETag")
        if not etag and resp.headers["Cache-Control"] != NO_STORE:
            etag = '"' + hashlib.sha256(body).hexdigest()[:20] + '"'
            resp.headers["ETag"] = etag
        # ----- conditional request: 304 with no body
        inm = request.headers.get("If-None-Match")
        if etag and inm and etag.strip('W/"') in [x.strip().strip('W/').strip('"') for x in inm.split(",")]:
            r304 = current_app.response_class(status=304)
            for h in ("ETag", "Cache-Control", "Vary", "Last-Modified", "Content-Type"):
                if h in resp.headers and h != "Content-Type": r304.headers[h] = resp.headers[h]
            r304.headers["Vary"] = "Accept-Encoding"
            return r304
        # ----- compression
        if ctype in COMPRESSIBLE and len(body) >= MIN_BYTES and "Content-Encoding" not in resp.headers:
            resp.headers.add("Vary", "Accept-Encoding")
            enc = _pick_encoding()
            if enc:
                is_static = path.startswith("/static/") or path in ("/",)
                key = (path, etag, enc)
                out = _cache.get(key) if is_static else None
                if out is None:
                    out = _compress(body, enc, 11 if path.startswith("/static/dist/") else 5)
                    if is_static and len(_cache) < 200: _cache[key] = out
                if len(out) < len(body):
                    resp.set_data(out)
                    resp.headers["Content-Encoding"] = enc
                    resp.headers["Content-Length"] = str(len(out))
                    if etag and not etag.startswith("W/"): resp.headers["ETag"] = etag  # same validator for both encodings is acceptable here: Vary is set
        if "Accept-Ranges" not in resp.headers and path.startswith("/static/"):
            resp.headers["Accept-Ranges"] = "bytes"
        return resp
