"""Lab 8 / Task 2: event store (persistence) and domain-event publisher for the WebSocket engine.
Every user-relevant event is written to the `events` table with a parameterised query, so a client that was
offline can ask for everything after the last event id it saw (replay on reconnect).
Presence signals (occupancy counts, seat colour changes) are broadcast but not stored: the client re-fetches them over HTTP."""
import json
from datetime import datetime, timedelta
import database

RETENTION_DAYS = 7
ROOM_ALL, ROOM_ADMIN = "all", "admin"
def floor_room(f): return "floor:" + str(f)
def user_room(sid): return "user:" + str(sid)

_hub = None          # set by ws_server.start(); exposes broadcast_threadsafe(event)
_warned = set()      # (kind, student_id) pairs already warned, so warnings are sent once
def set_hub(h):
    global _hub; _hub = h

def init_events():
    conn = database.get_connection()
    conn.execute("""CREATE TABLE IF NOT EXISTS events(
        id INTEGER PRIMARY KEY AUTOINCREMENT, room TEXT NOT NULL, kind TEXT NOT NULL,
        payload TEXT NOT NULL, created_at TEXT NOT NULL)""")
    conn.execute("CREATE INDEX IF NOT EXISTS ix_events_room_id ON events(room, id)")
    conn.execute("DELETE FROM events WHERE created_at < ?", ((datetime.now() - timedelta(days=RETENTION_DAYS)).isoformat(),))
    conn.commit(); conn.close()

def _row_to_event(r):
    return {"id": r["id"], "room": r["room"], "kind": r["kind"], "ts": r["created_at"], "data": json.loads(r["payload"])}

def latest_id():
    conn = database.get_connection()
    r = conn.execute("SELECT COALESCE(MAX(id), 0) AS m FROM events").fetchone()
    conn.close(); return r["m"]

def publish(room, kind, data, persist=True):
    """Store (optional) then fan out to every connected client in `room`. Safe to call from any thread."""
    now = datetime.now().isoformat(timespec="seconds")
    if persist:
        conn = database.get_connection()
        cur = conn.execute("INSERT INTO events (room, kind, payload, created_at) VALUES (?,?,?,?)",
                           (room, kind, json.dumps(data, separators=(",", ":")), now))
        conn.commit(); eid = cur.lastrowid; conn.close()
    else:
        eid = None
    event = {"id": eid, "room": room, "kind": kind, "ts": now, "data": data}
    if _hub is not None: _hub.broadcast_threadsafe(event)
    return event

def history_since(last_id, rooms, limit=200):
    """Missed events for a reconnecting client. Always exactly four room slots, so the SQL text is constant."""
    slots = (list(rooms) + ["", "", "", ""])[:4]
    conn = database.get_connection()
    rows = conn.execute("""SELECT id, room, kind, payload, created_at FROM events
                           WHERE id > ? AND room IN (?,?,?,?) ORDER BY id LIMIT ?""",
                        (int(last_id), *slots, int(limit) + 1)).fetchall()
    conn.close()
    events = [_row_to_event(r) for r in rows[:limit]]
    return events, len(rows) > limit

# ---- domain events raised by database.py -------------------------------------------------------------
END_MESSAGES = {
    "force_librarian": "A librarian released your seat.",
    "auto_away": "Your seat was released because you were away too long.",
    "auto_max_time": "Your maximum session time was reached.",
    "auto_inactive": "Your seat was released because you did not confirm you were still here.",
    "auto_closing_time": "The library has closed.",
}
def _occupancy():
    s = database.get_active_sessions()
    floors = {"ground": 0, "first": 0, "second": 0}
    for x in s:
        if x.get("floor") in floors: floors[x["floor"]] += 1
    return {"current": len(s), "floors": floors}

def on_domain_event(kind, **d):
    try:
        floor, seat = d.get("floor"), d.get("seat_number")
        if kind == "checkin":
            publish(ROOM_ADMIN, "session_started", {"student_id": d["student_id"], "full_name": d["full_name"], "floor": floor, "seat_number": seat})
            publish(floor_room(floor), "seat_update", {"seat_id": seat, "status": "occupied"}, persist=False)
        elif kind == "checkout":
            _warned.discard(("away", d["student_id"])); _warned.discard(("end", d["student_id"]))
            publish(ROOM_ADMIN, "session_ended", {"student_id": d["student_id"], "full_name": d["full_name"], "floor": floor,
                                                  "seat_number": seat, "reason": d["reason"]})
            publish(floor_room(floor), "seat_update", {"seat_id": seat, "status": "free"}, persist=False)
            if d["reason"] != "manual":
                publish(user_room(d["student_id"]), "session_ended",
                        {"reason": d["reason"], "message": END_MESSAGES.get(d["reason"], "Your session was ended.")})
        elif kind in ("away", "back"):
            if kind == "back": _warned.discard(("away", d["student_id"]))
            publish(floor_room(floor), "seat_update", {"seat_id": seat, "status": "away" if kind == "away" else "occupied"}, persist=False)
            publish(ROOM_ADMIN, "status_changed", {"student_id": d["student_id"], "status": "away" if kind == "away" else "present"}, persist=False)
        elif kind in ("seat_out", "seat_restored"):
            publish(floor_room(floor), "seat_update", {"seat_id": seat, "status": "out_of_service" if kind == "seat_out" else "free"}, persist=False)
        publish(ROOM_ALL, "occupancy", _occupancy(), persist=False)
    except Exception as e:           # a realtime failure must never break the HTTP request that caused it
        print("realtime error:", e)

def warn_once(kind, student_id, message, minutes_left):
    """Private, persisted notification (used by the cleanup loop for 'away' and 'session ending' warnings)."""
    key = (kind, student_id)
    if key in _warned: return
    _warned.add(key)
    publish(user_room(student_id), kind + "_warning", {"message": message, "minutes_left": minutes_left})
