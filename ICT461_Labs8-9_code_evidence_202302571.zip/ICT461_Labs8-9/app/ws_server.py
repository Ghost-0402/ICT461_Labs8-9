"""Lab 8: authenticated WebSocket engine (RFC 6455) that runs next to the Flask HTTP server in the same process.

Task 1  authentication during the HTTP Upgrade handshake (401/403/429 before any socket exists), rooms/channels
Task 2  strict JSON frame validation, persistence + replay through realtime.py
Task 3  server-side Ping/Pong heartbeat with eviction of half-open connections
Library: `websockets` (asyncio). We switch off its built-in keep-alive (ping_interval=None) and run our own heartbeat task
so that every Ping, Pong and eviction is logged and counted."""
from urllib.parse import urlsplit, parse_qs
import asyncio, json, logging, os, threading, time
from collections import deque
from http import HTTPStatus
from http.cookies import SimpleCookie
from websockets.asyncio.server import serve
from websockets.exceptions import ConnectionClosed
import realtime
from ownership import COOKIE as SEAT_COOKIE, student_for
from database import get_session
from ws_schemas import validate_frame

log = logging.getLogger("mu.ws")
if not log.handlers:
    h = logging.StreamHandler(); h.setFormatter(logging.Formatter("%(asctime)s.%(msecs)03d %(message)s", "%H:%M:%S")); log.addHandler(h)
    if os.environ.get("WS_LOG_FILE"):
        fh = logging.FileHandler(os.environ["WS_LOG_FILE"]); fh.setFormatter(h.formatter); log.addHandler(fh)
    log.setLevel(logging.INFO); log.propagate = False

CFG = {
    "port": int(os.environ.get("WS_PORT", "5050")),
    "heartbeat_interval": float(os.environ.get("WS_HEARTBEAT_INTERVAL", "25")),   # seconds between Ping frames
    "heartbeat_timeout": float(os.environ.get("WS_HEARTBEAT_TIMEOUT", "10")),     # seconds to wait for the Pong
    "max_frame_bytes": 4096, "max_conn_per_user": 3,
    "rate_limit": (10, 10.0),                                                     # 10 frames per 10 s per connection
    "max_violations": 3,
}
def allowed_origins():
    raw = os.environ.get("WS_ALLOWED_ORIGINS", "http://127.0.0.1:5000,http://localhost:5000,https://127.0.0.1:8443,https://localhost:8443")
    return {o.strip() for o in raw.split(",") if o.strip()}

class Client:
    def __init__(self, ws, ident):
        self.ws, self.ident = ws, ident
        self.rooms = set(); self.last_pong = time.time(); self.stamps = deque(); self.violations = 0
        self.label = ident.get("student_id") or "admin"

class Hub:
    def __init__(self, loop):
        self.loop = loop; self.rooms = {}; self.clients = set()
        self.stats = {"accepted": 0, "rejected_401": 0, "rejected_403": 0, "rejected_429": 0, "evicted": 0,
                      "invalid_frames": 0, "frames_in": 0, "events_out": 0, "pings": 0, "pongs": 0}
    def add(self, c, rooms):
        self.clients.add(c)
        for r in rooms: self.rooms.setdefault(r, set()).add(c); c.rooms.add(r)
    def remove(self, c):
        self.clients.discard(c)
        for r in list(c.rooms):
            self.rooms.get(r, set()).discard(c)
            if not self.rooms.get(r): self.rooms.pop(r, None)
    def count_for(self, ident):
        return sum(1 for c in self.clients if c.ident.get("student_id") == ident.get("student_id") and c.ident["role"] == ident["role"])
    def snapshot(self):
        return {"connected": len(self.clients), "students": sum(1 for c in self.clients if c.ident["role"] == "student"),
                "admins": sum(1 for c in self.clients if c.ident["role"] == "admin"),
                "rooms": {r: len(m) for r, m in self.rooms.items()}, **self.stats,
                "heartbeat_interval_s": CFG["heartbeat_interval"], "heartbeat_timeout_s": CFG["heartbeat_timeout"]}
    async def _send(self, c, text):
        try:
            await asyncio.wait_for(c.ws.send(text), 5)
            self.stats["events_out"] += 1
        except Exception:                                   # slow or dead peer: drop it, never block the others
            c.ws.transport.abort()
    async def broadcast(self, event):
        text = json.dumps({"type": "event", **event}, separators=(",", ":"))
        targets = list(self.rooms.get(event["room"], ()))
        if targets: await asyncio.gather(*(self._send(c, text) for c in targets))
    def broadcast_threadsafe(self, event):
        asyncio.run_coroutine_threadsafe(self.broadcast(event), self.loop)

hub = None
FLASK_APP = None

def _cookies(request):
    c = SimpleCookie()
    try: c.load(request.headers.get("Cookie", ""))
    except Exception: return {}
    return {k: m.value for k, m in c.items()}

def authenticate(request):
    """Return (identity, None) or (None, (status, reason)). Runs during the HTTP Upgrade, before the socket is accepted."""
    origin = request.headers.get("Origin")
    if origin is not None and origin not in allowed_origins():
        return None, (HTTPStatus.FORBIDDEN, "origin not allowed")                 # blocks cross-site WebSocket hijacking
    ck = _cookies(request)
    sess = ck.get("session")
    want = parse_qs(urlsplit(request.path).query).get("as", [""])[0]            # page says which login it is using (a browser may hold both)
    if sess and want != "student":                                                                     # librarian: signed Flask session cookie
        try:
            ser = FLASK_APP.session_interface.get_signing_serializer(FLASK_APP)
            data = ser.loads(sess, max_age=int(FLASK_APP.permanent_session_lifetime.total_seconds()))
            if data.get("admin_logged_in"): return {"role": "admin", "student_id": None}, None
        except Exception: pass
    sid = student_for(ck.get(SEAT_COOKIE))                                         # student: HttpOnly seat token from check-in
    if sid:
        s = get_session(sid)
        if s: return {"role": "student", "student_id": sid, "floor": s["floor"], "seat": s["seat_number"], "name": s["full_name"]}, None
    return None, (HTTPStatus.UNAUTHORIZED, "authentication required")

def rooms_for(ident):
    if ident["role"] == "admin": return [realtime.ROOM_ALL, realtime.ROOM_ADMIN]
    return [realtime.ROOM_ALL, realtime.floor_room(ident["floor"]), realtime.user_room(ident["student_id"])]

async def process_request(connection, request):
    if urlsplit(request.path).path != "/api/ws":
        return connection.respond(HTTPStatus.NOT_FOUND, "not found\n")
    ident, err = authenticate(request)
    if err:
        key = "rejected_403" if err[0] == HTTPStatus.FORBIDDEN else "rejected_401"
        hub.stats[key] += 1
        log.info(f"HANDSHAKE REJECTED {int(err[0])} {err[1]} (origin={request.headers.get('Origin')})")
        return connection.respond(err[0], err[1] + "\n")
    if hub.count_for(ident) >= CFG["max_conn_per_user"]:
        hub.stats["rejected_429"] += 1
        log.info(f"HANDSHAKE REJECTED 429 too many connections for {ident.get('student_id') or 'admin'}")
        return connection.respond(HTTPStatus.TOO_MANY_REQUESTS, "too many connections\n")
    connection.mu_identity = ident
    return None

async def heartbeat(c):
    """Task 3: send a Ping every interval; a client that does not Pong within the timeout is terminated."""
    ws = c.ws
    try:
        while True:
            await asyncio.sleep(CFG["heartbeat_interval"])
            t0 = time.monotonic()
            pong = await ws.ping()                                    # sends a Ping control frame (opcode 0x9)
            hub.stats["pings"] += 1
            log.info(f"PING  -> {c.label} (opcode 0x9)")
            try:
                await asyncio.wait_for(pong, CFG["heartbeat_timeout"])   # resolves when the Pong (opcode 0xA) arrives
            except asyncio.TimeoutError:
                hub.stats["evicted"] += 1
                log.info(f"EVICT {c.label}: no Pong within {CFG['heartbeat_timeout']}s, terminating half-open connection "
                         f"(clients before={len(hub.clients)})")
                ws.transport.abort()
                return
            c.last_pong = time.time(); hub.stats["pongs"] += 1
            log.info(f"PONG  <- {c.label} (opcode 0xA) rtt={(time.monotonic()-t0)*1000:.1f}ms")
    except (ConnectionClosed, asyncio.CancelledError):
        return

def _err(code, msg): return json.dumps({"type": "error", "code": code, "message": msg})

async def handle(c, raw):
    ws, ident = c.ws, c.ident
    hub.stats["frames_in"] += 1
    now = time.monotonic(); n, per = CFG["rate_limit"]
    while c.stamps and now - c.stamps[0] > per: c.stamps.popleft()
    c.stamps.append(now)
    if len(c.stamps) > n:
        c.violations += 1; await ws.send(_err("rate_limited", "too many messages")); return
    if isinstance(raw, bytes):
        await ws.close(1003, "text frames only"); return
    try: obj = json.loads(raw)
    except ValueError:
        c.violations += 1; hub.stats["invalid_frames"] += 1
        await ws.send(_err("invalid_json", "frame is not valid JSON")); return
    why = validate_frame(obj)
    if why:
        c.violations += 1; hub.stats["invalid_frames"] += 1
        log.info(f"INVALID FRAME from {c.label}: {why}")
        await ws.send(_err("invalid_frame", why)); return
    t = obj["type"]
    if t == "sync":
        events, truncated = realtime.history_since(obj["last_id"], rooms_for(ident))
        for e in events: await ws.send(json.dumps({"type": "event", **e}, separators=(",", ":")))
        await ws.send(json.dumps({"type": "synced", "count": len(events), "truncated": truncated,
                                  "last_id": events[-1]["id"] if events else obj["last_id"]}))
        log.info(f"SYNC  {c.label}: replayed {len(events)} missed event(s) after id {obj['last_id']}")
    elif t == "report" and ident["role"] == "student":
        e = realtime.publish(realtime.ROOM_ADMIN, "issue_report", {"student_id": ident["student_id"], "name": ident["name"],
                             "seat": ident["seat"], "text": obj["text"]})
        await ws.send(json.dumps({"type": "ack", "of": "report", "id": e["id"]}))
    elif t == "announce" and ident["role"] == "admin":
        e = realtime.publish(realtime.ROOM_ALL, "announcement", {"text": obj["text"], "by": "Librarian"})
        await ws.send(json.dumps({"type": "ack", "of": "announce", "id": e["id"]}))
    else:
        c.violations += 1; await ws.send(_err("forbidden", f"'{t}' is not allowed for role {ident['role']}"))

async def handler(ws):
    ident = ws.mu_identity
    c = Client(ws, ident)
    hub.add(c, rooms_for(ident)); hub.stats["accepted"] += 1
    log.info(f"CONNECT {c.label} role={ident['role']} rooms={sorted(c.rooms)} total={len(hub.clients)}")
    hb = asyncio.create_task(heartbeat(c))
    try:
        await ws.send(json.dumps({"type": "hello", "role": ident["role"], "rooms": sorted(c.rooms),
                                  "latest_id": realtime.latest_id(), "heartbeat_s": CFG["heartbeat_interval"]}))
        async for raw in ws:
            await handle(c, raw)
            if c.violations >= CFG["max_violations"]:
                log.info(f"CLOSE {c.label}: too many violations"); await ws.close(1008, "policy violation"); break
    except ConnectionClosed:
        pass
    finally:
        hb.cancel(); hub.remove(c)
        log.info(f"DISCONNECT {c.label} total={len(hub.clients)}")

def start(flask_app, host=None, port=None, ssl_context=None):
    """Start the WebSocket server in a daemon thread with its own event loop; returns the Hub."""
    global hub, FLASK_APP
    FLASK_APP = flask_app; host = host or os.environ.get("HOST", "127.0.0.1"); port = port or CFG["port"]
    ready = threading.Event()
    def run():
        global hub
        loop = asyncio.new_event_loop(); asyncio.set_event_loop(loop)
        async def main():
            global hub
            hub = Hub(loop); realtime.set_hub(hub)
            async with serve(handler, host, port, process_request=process_request, max_size=CFG["max_frame_bytes"],
                             ping_interval=None, compression=None, ssl=ssl_context) as server:
                log.info(f"WebSocket server listening on ws://{host}:{port}/api/ws (heartbeat {CFG['heartbeat_interval']}s/{CFG['heartbeat_timeout']}s)" + (" [TLS]" if ssl_context else ""))
                ready.set(); await server.serve_forever()
        loop.run_until_complete(main())
    threading.Thread(target=run, daemon=True, name="ws-server").start()
    ready.wait(10); return hub
