(async () => {
  const me = await api("GET", "/api/v1/auth/me");
  if (me.status === 401) { location.href = "/login"; return; }
  document.getElementById("who").textContent = me.data.full_name + " (" + me.data.student_id + ")";
})();
document.getElementById("checkin-form").addEventListener("submit", async e => {
  e.preventDefault(); const f = e.target;
  const needs = [...f.querySelectorAll("input[name=needs]:checked")].map(x => x.value);
  const { status, data } = await api("POST", "/api/v1/checkins", { floor: f.floor.value, seat_number: f.seat_number.value.toUpperCase(), planned_hours: Number(f.planned_hours.value), needs });
  if (status === 401) { location.href = "/login"; return; }
  if (status === 201) { const b = f.querySelector(".msg"); b.textContent = `Checked in at seat ${data.seat_number} (${data.floor} floor).`; b.className = "msg ok"; f.querySelectorAll(".err").forEach(x => x.textContent = ""); }
  else showErrors(f, status, data);
});
document.getElementById("release").addEventListener("click", async () => {
  const r = await api("DELETE", "/api/v1/checkins/current"); const b = document.querySelector("#checkin-form .msg");
  b.textContent = r.status === 204 ? "Seat released." : r.data.detail; b.className = "msg " + (r.status === 204 ? "ok" : "bad");
});
document.getElementById("logout").addEventListener("click", async () => { await api("POST", "/api/v1/auth/logout"); location.href = "/login"; });
