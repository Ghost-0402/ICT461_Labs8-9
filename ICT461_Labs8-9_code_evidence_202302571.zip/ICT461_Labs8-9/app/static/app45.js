async function api(method, path, body) {
  const r = await fetch(path, { method, credentials: "same-origin",
    headers: body ? { "Content-Type": "application/json" } : {}, body: body ? JSON.stringify(body) : undefined });
  let data = null; if (r.status !== 204) { try { data = await r.json(); } catch (e) {} }
  return { status: r.status, data };
}
function showErrors(form, status, data) {
  form.querySelectorAll(".err").forEach(e => e.textContent = "");
  const box = form.querySelector(".msg"); box.textContent = ""; box.className = "msg";
  if (status === 422 && data.errors) {
    for (const [f, m] of Object.entries(data.errors)) { const e = form.querySelector(`[data-err="${f}"]`); if (e) e.textContent = m; }
    box.textContent = data.detail; box.className = "msg bad";
  } else if (status === 429) { box.textContent = "Too many attempts. " + data.detail; box.className = "msg bad"; }
  else if (status >= 400) { box.textContent = data.detail || data.title; box.className = "msg bad"; }
}
