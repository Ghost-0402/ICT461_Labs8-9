const TIPS=["Use the Pomodoro technique: 25 min focused, 5 min break.","Reviewing notes within 24 hours improves retention by 60%.","Teach what you've learned — it solidifies understanding.","Break large tasks into timed chunks to avoid overwhelm.","Hydrate regularly; even mild dehydration cuts concentration."];
document.getElementById('study-tip').textContent='"'+TIPS[Math.floor(Math.random()*TIPS.length)]+'"';

let gpsCoords=null,sessionData=null,timerInterval=null,checkInTime=null;
let pingInterval=null,pingTimer=null,pingCountdown=0;
let selectedFloor='ground',selectedSeat=null;
let pomInterval=null,pomSeconds=25*60;
let studentInfo={sid:'',name:'',course:''};
let awayStart=null,maxSessionMin=180,awayLimitMin=20,pingGraceMin=10,pingEveryMin=45;
let warnedAway=false,warnedEnd=false,statusPoll=null,checkingActive=false,lastActiveCheck=0;

function setTheme(t){document.documentElement.setAttribute('data-theme',t);['dark','navy','light'].forEach(x=>document.getElementById('tbtn-'+x).classList.toggle('active',x===t));localStorage.setItem('mu-theme',t);}
setTheme(localStorage.getItem('mu-theme')||'dark');

function goTab(n){
  if(n===2&&!studentInfo.sid)return;
  if(n===3&&!gpsCoords)return;
  [1,2,3].forEach(i=>{
    document.getElementById('panel-'+i).style.display=i===n?'block':'none';
    const t=document.getElementById('ftab-'+i);
    t.classList.remove('active','done','locked');
    if(i===n)t.classList.add('active');
    else if(i<n)t.classList.add('done');
    else t.classList.add('locked');
  });
  if(n===3)loadAllFloors();
}

function doLogin(){
  const sid=document.getElementById('inp-sid').value.trim();
  const name=document.getElementById('inp-name').value.trim();
  const course=document.getElementById('inp-course').value.trim();
  if(!sid||!name){showAlert(1,'Please enter your Student ID and Full Name.');return;}
  if(!/^\d{9}$/.test(sid)){showAlert(1,'Student ID must be exactly 9 digits.');return;}
  studentInfo={sid,name,course:course||'Not specified'};
  hideAlert(1);goTab(2);
}

function getLocation(){
  const btn=document.getElementById('gps-btn');
  setGps('loading','Requesting your GPS location...');btn.disabled=true;
  if(!navigator.geolocation){setGps('error','GPS not supported. Please use Chrome on your phone.');btn.disabled=false;return;}
  navigator.geolocation.getCurrentPosition(
    pos=>{gpsCoords={lat:pos.coords.latitude,lon:pos.coords.longitude};setGps('ok','Location verified (+-'+Math.round(pos.coords.accuracy)+'m accuracy). You may proceed.');document.getElementById('gps-next').disabled=false;btn.textContent='Verified';btn.disabled=true;},
    err=>{const m={1:'Location denied. Please allow location in browser settings.',2:'GPS unavailable. Try near a window.',3:'Timed out. Please try again.'};setGps('error',m[err.code]||'Could not get location.');btn.disabled=false;btn.textContent='Verify My Location';},
    {enableHighAccuracy:true,timeout:12000,maximumAge:0}
  );
}
function setGps(t,m){document.getElementById('gps-status').className='gps-'+t;document.getElementById('gps-txt').textContent=m;}

async function loadAllFloors(){
  for(const f of['ground','first','second']){
    try{const r=await fetch('/api/seats/'+f);const d=await r.json();const av=d.seats.filter(s=>!s.occupied).length;document.getElementById('fav-'+f).textContent=av+' free';}catch(e){}
  }
  loadSeats(selectedFloor);
}

function selectFloor(floor){
  selectedFloor=floor;selectedSeat=null;
  ['ground','first','second'].forEach(f=>document.getElementById('ftab-'+f).classList.toggle('active',f===floor));
  document.getElementById('inp-seat').value='';document.getElementById('checkin-btn').disabled=true;
  loadSeats(floor);
}

async function loadSeats(floor){
  const grid=document.getElementById('seat-grid');
  grid.innerHTML='<div style="color:var(--muted);font-size:13px;padding:10px">Loading seats...</div>';
  try{
    const r=await fetch('/api/seats/'+floor);const d=await r.json();
    grid.innerHTML='';
    d.seats.forEach(seat=>{
      const el=document.createElement('button');
      var st=seat.status||(seat.occupied?'occupied':'free');
      var cls=st==='away'?' away':st==='out_of_service'?' out':st==='occupied'?' occupied':'';
      el.className='seat'+cls+(seat.id===selectedSeat?' selected':'');
      el.textContent=seat.number;
      el.title=st==='free'?'Available':st==='away'?'Occupied (student away)':st==='out_of_service'?'Out of service':'Occupied';
      if(st==='free')el.onclick=function(){pickSeat(seat.id,el)};
      grid.appendChild(el);
    });
  }catch(e){grid.innerHTML='<p style="color:var(--red);font-size:13px">Failed to load seats.</p>';}
}

function pickSeat(seatId,el){selectedSeat=seatId;document.querySelectorAll('.seat').forEach(s=>s.classList.remove('selected'));el.classList.add('selected');document.getElementById('inp-seat').value=seatId;document.getElementById('checkin-btn').disabled=false;hideAlert(3);}

function confirmSeatInput(){
  var val=document.getElementById('inp-seat').value.trim().toUpperCase();
  var prefix={ground:'G',first:'F',second:'S'}[selectedFloor];
  if(/^\d+$/.test(val))val=prefix+val;
  var num=parseInt(val.replace(/^[GFS]/,''));
  if(!val.startsWith(prefix)||isNaN(num)||num<1||num>40){showAlert(3,'Invalid seat. Use format '+prefix+'1 to '+prefix+'40.');return;}
  selectedSeat=val;document.getElementById('inp-seat').value=val;document.getElementById('checkin-btn').disabled=false;hideAlert(3);
  document.querySelectorAll('.seat').forEach(function(el,i){el.classList.toggle('selected',i+1===num&&!el.classList.contains('occupied'));});
}

async function doCheckin(){
  if(!selectedFloor||!selectedSeat){showAlert(3,'Please select a floor and seat.');return;}
  var btn=document.getElementById('checkin-btn');btn.disabled=true;btn.textContent='Checking in...';
  try{
    var res=await fetch('/api/checkin',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({student_id:studentInfo.sid,full_name:studentInfo.name,course:studentInfo.course,floor:selectedFloor,seat_number:selectedSeat,latitude:gpsCoords.lat,longitude:gpsCoords.lon})});
    var data=await res.json();
    if(data.success){
      sessionData=data;checkInTime=new Date(data.check_in_time);
      maxSessionMin=data.max_session_minutes||180;awayLimitMin=data.away_limit_minutes||20;
      pingGraceMin=data.ping_grace_minutes||10;pingEveryMin=data.ping_interval_minutes||45;
      awayStart=null;warnedAway=false;warnedEnd=false;
      showSession(data);startPingSchedule();
    }
    else{showAlert(3,data.error);btn.disabled=false;btn.textContent='✅ Check In to Library';loadSeats(selectedFloor);}
  }catch(e){showAlert(3,'Network error. Please try again.');btn.disabled=false;btn.textContent='✅ Check In to Library';}
}

function showSession(data){
  document.getElementById('flow-tabs-wrap').style.display='none';
  document.getElementById('main-card').style.display='none';
  document.getElementById('session-panel').style.display='block';
  document.getElementById('away-box').style.display='none';
  document.getElementById('sess-actions').style.display='flex';
  var fl={ground:'Ground Floor',first:'1st Floor',second:'2nd Floor'};
  document.getElementById('sess-name').textContent='Welcome, '+data.full_name.split(' ')[0]+'!';
  document.getElementById('sess-id').textContent=data.student_id+' · '+data.course;
  document.getElementById('sess-chips').innerHTML='<div class="chip">Floor: <strong>'+fl[data.floor]+'</strong></div><div class="chip">Seat <strong>'+data.seat_number+'</strong></div><div class="chip">In at <strong>'+formatTime(data.check_in_time)+'</strong></div><div class="chip">Ends at <strong>'+formatTime(new Date(new Date(data.check_in_time).getTime()+maxSessionMin*60000).toISOString())+'</strong></div>';
  clearInterval(timerInterval);tick();
  timerInterval=setInterval(tick,1000);
  clearInterval(statusPoll);statusPoll=setInterval(checkStillActive,10000);
  refreshActiveSessions();startLive();
}

function mmss(s){var m=Math.floor(s/60),x=s%60;return (m<10?'0':'')+m+':'+(x<10?'0':'')+x;}

function tick(){
  if(!checkInTime||!sessionData)return;
  var elapsed=Math.floor((Date.now()-checkInTime.getTime())/1000);
  var left=Math.max(0,maxSessionMin*60-elapsed);
  document.getElementById('sess-timer').textContent=formatDuration(left);
  document.getElementById('sess-timer-lbl').textContent=left>0?'Time left in this session':'Session ended';
  if(left<=600&&left>0&&!warnedEnd){warnedEnd=true;showToast('Your session ends in 10 minutes. You can check in again afterwards if the seat is free.');}
  if(awayStart){
    var awayLeft=Math.max(0,awayLimitMin*60-Math.floor((Date.now()-awayStart.getTime())/1000));
    document.getElementById('away-timer').textContent=mmss(awayLeft);
    if(awayLeft<=300&&awayLeft>0&&!warnedAway){warnedAway=true;showToast('5 minutes left to return to your seat.','error');}
    if(awayLeft<=0)checkStillActive();
  }else if(left<=0){checkStillActive();}
}

async function checkStillActive(){
  if(!sessionData||checkingActive||Date.now()-lastActiveCheck<5000)return;
  checkingActive=true;lastActiveCheck=Date.now();
  try{
    var r=await fetch('/api/session_status/'+sessionData.student_id);var d=await r.json();
    if(!d.active){resetToLogin();showToast('Your seat was released (session ended, away too long, or freed by a librarian). Check in again to continue.','error');}
  }catch(e){}
  checkingActive=false;
}

async function doAway(){
  if(!sessionData)return;
  try{
    var r=await fetch('/api/away',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({student_id:sessionData.student_id})});
    var d=await r.json();
    if(d.success){
      awayStart=new Date(d.away_since);warnedAway=false;hidePing();
      awayLimitMin=d.away_limit_minutes||awayLimitMin;
      document.getElementById('away-box').style.display='block';
      document.getElementById('sess-actions').style.display='none';
      tick();refreshActiveSessions();
    }else{showToast(d.error||'Could not start away timer.','error');}
  }catch(e){showToast('Network error. Please try again.','error');}
}

async function doBack(){
  if(!sessionData)return;
  try{
    var r=await fetch('/api/back',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({student_id:sessionData.student_id})});
    var d=await r.json();
    if(d.success){
      awayStart=null;
      document.getElementById('away-box').style.display='none';
      document.getElementById('sess-actions').style.display='flex';
      startPingSchedule();tick();refreshActiveSessions();showToast('Welcome back! Your seat is still yours.');
    }else{resetToLogin();showToast(d.error||'Your seat was released.','error');}
  }catch(e){showToast('Network error. Please try again.','error');}
}

function resetToLogin(){
  clearInterval(timerInterval);clearInterval(pingInterval);clearInterval(pingTimer);clearInterval(statusPoll);hidePing();
  sessionData=null;gpsCoords=null;selectedSeat=null;awayStart=null;checkInTime=null;
  document.getElementById('flow-tabs-wrap').style.display='flex';
  document.getElementById('main-card').style.display='block';
  document.getElementById('session-panel').style.display='none';
  ['inp-sid','inp-name','inp-course','inp-seat'].forEach(function(id){document.getElementById(id).value='';});
  setGps('idle','Tap the button below to request your GPS location.');
  document.getElementById('gps-btn').textContent='Verify My Location';
  document.getElementById('gps-btn').disabled=false;
  document.getElementById('gps-next').disabled=true;
  document.getElementById('checkin-btn').textContent='✅ Check In to Library';
  document.getElementById('checkin-btn').disabled=true;
  stopLive();goTab(1);refreshOccupancy();
}

async function doCheckout(){
  if(!sessionData)return;hidePing();
  try{
    var res=await fetch('/api/checkout',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({student_id:sessionData.student_id})});
    var data=await res.json();
    resetToLogin();
    if(data.success)showToast('Seat released! You studied for '+data.duration+'. Great work!');
  }catch(e){}
}

function startPingSchedule(){clearInterval(pingInterval);pingInterval=setInterval(function(){if(!awayStart)showPing();},pingEveryMin*60*1000);}
function showPing(){pingCountdown=pingGraceMin*60;document.getElementById('ping-overlay').classList.add('show');updatePingDisplay();clearInterval(pingTimer);pingTimer=setInterval(function(){pingCountdown--;updatePingDisplay();if(pingCountdown<=0){clearInterval(pingTimer);doCheckout();}},1000);}
function updatePingDisplay(){var m=Math.floor(pingCountdown/60),s=pingCountdown%60;document.getElementById('ping-cd').textContent=(m<10?'0':'')+m+':'+(s<10?'0':'')+s;}
async function confirmStillHere(){hidePing();if(sessionData){await fetch('/api/activity',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({student_id:sessionData.student_id})});startPingSchedule();}}
function hidePing(){document.getElementById('ping-overlay').classList.remove('show');clearInterval(pingTimer);}

async function refreshOccupancy(){
  try{
    var r=await fetch('/api/occupancy');var d=await r.json();
    document.getElementById('header-occ').textContent=d.current+' / '+d.capacity+' in library';
    document.getElementById('occ-num').textContent=d.current;
    document.getElementById('occ-avail').textContent=d.available+' seats available';
    var pct=d.percentage,c=pct<50?'#22c55e':pct<80?'#f59e0b':'#ef4444',lbl=pct<50?'Available':pct<80?'Filling Up':'Almost Full';
    document.getElementById('occ-bar').style.cssText='width:'+pct+'%;background:'+c;
    document.getElementById('occ-num').style.color=c;
    document.getElementById('occ-badge').textContent=lbl;
    document.getElementById('occ-badge').style.cssText='background:'+c+'20;color:'+c+';border:1px solid '+c+'40';
    var fl=d.floors||{};
    ['ground','first','second'].forEach(function(f){var cnt=fl[f]||0,p=Math.min((cnt/40)*100,100);document.getElementById('fm-'+f).style.width=p+'%';document.getElementById('fc-'+f).textContent=cnt;});
  }catch(e){}
}

async function refreshActiveSessions(){
  try{
    var r=await fetch('/api/active_sessions');var sessions=await r.json();
    var fl={ground:'Ground Floor',first:'1st Floor',second:'2nd Floor'};
    document.getElementById('active-count-lbl').textContent=sessions.length+' student'+(sessions.length!==1?'s':'')+' inside';
    var list=document.getElementById('active-list');
    if(!sessions.length){list.innerHTML='<p style="color:var(--dim);font-size:13px;text-align:center;padding:14px">No other students checked in.</p>';return;}
    list.innerHTML=sessions.map(function(s){
      var dur=Math.floor((Date.now()-new Date(s.check_in_time).getTime())/1000);
      var isMe=!!s.is_me;
      return '<div class="active-row '+(isMe?'me':'')+'"><div style="display:flex;align-items:center;gap:11px"><div class="av-avatar '+(isMe?'me':'')+'">'+esc(s.full_name.charAt(0).toUpperCase())+'</div><div><div style="font-size:14px;font-weight:600;color:var(--text)">'+s.full_name+(isMe?' <span style="font-size:10px;color:var(--gold)">(you)</span>':'')+'</div><div style="font-size:11px;color:var(--dim)">'+esc(fl[s.floor]||'—')+' · Seat '+esc(s.seat_number||'—')+'</div></div></div><div style="text-align:right"><div style="font-size:12px;color:var(--muted);font-weight:600">'+formatDuration(dur)+'</div><div style="font-size:10px;color:var(--dim)">'+formatTime(s.check_in_time)+'</div></div></div>';
    }).join('');
  }catch(e){}
}

function startPomodoro(){document.getElementById('pomodoro-display').style.display='block';pomSeconds=25*60;clearInterval(pomInterval);pomInterval=setInterval(function(){if(pomSeconds>0){pomSeconds--;updatePomDisplay();}else{clearInterval(pomInterval);document.getElementById('pom-lbl').textContent='Break Time!';document.getElementById('pom-timer').style.color='#22c55e';}},1000);}
function stopPomodoro(){clearInterval(pomInterval);document.getElementById('pomodoro-display').style.display='none';pomSeconds=25*60;}
function updatePomDisplay(){var m=Math.floor(pomSeconds/60),s=pomSeconds%60;document.getElementById('pom-timer').textContent=(m<10?'0':'')+m+':'+(s<10?'0':'')+s;}

function formatDuration(s){var h=Math.floor(s/3600),m=Math.floor((s%3600)/60),sc=s%60;if(h>0)return h+'h '+m+'m';if(m>0)return m+'m '+sc+'s';return sc+'s';}
function formatTime(iso){return new Date(iso).toLocaleTimeString('en-ZM',{hour:'2-digit',minute:'2-digit'});}
function showAlert(p,msg){var el=document.getElementById('alert-'+p);el.className='alert alert-error';el.textContent=msg;el.style.display='block';}
function hideAlert(p){var el=document.getElementById('alert-'+p);if(el)el.style.display='none';}
function showToast(msg,type){var el=document.createElement('div');el.className='toast'+(type==='error'?' error':'');el.textContent=msg;document.body.appendChild(el);setTimeout(function(){el.remove();},5000);}

refreshOccupancy();
setInterval(function(){if(!Live.connected())refreshOccupancy();},15000);   // Lab 8: poll only while the live channel is down
setInterval(function(){if(sessionData&&!Live.connected())refreshActiveSessions();},10000);
setInterval(refreshOccupancy,120000);        // slow safety refresh

// Lab 6: contextual output encoding for every value placed into innerHTML / attributes
function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
// Lab 6: CSP-safe event delegation (no inline on* attributes). Only registered actions can run.
document.addEventListener('click',function(e){var el=e.target.closest('[data-click]');if(!el)return;var fn=ACTIONS[el.getAttribute('data-click')];if(fn){var a=[];try{a=JSON.parse(el.getAttribute('data-args')||'[]');}catch(x){}fn.apply(null,a);}});
function sendReport(){
  var el=document.getElementById('live-report-text'),t=el.value.trim();if(!t)return;
  if(Live.send({type:'report',text:t})){el.value='';showToast('Sent to the librarian.');}else showToast('Not connected yet. Try again in a moment.','error');
}
function reportIssue(){showToast('Use the Live updates box to message the librarian after you check in.');}
var liveTimer=null;
function liveSoon(fn){clearTimeout(liveTimer);liveTimer=setTimeout(fn,150);}
function startLive(){
  document.getElementById('live-box').style.display='block';
  Live.start({
    shouldRetry:function(){return !!sessionData;},
    onError:function(m){showToast('Server rejected the message: '+m,'error');},
    onEvent:function(ev){
      var d=ev.data||{};
      if(ev.kind==='occupancy'){liveSoon(function(){refreshOccupancy();if(sessionData)refreshActiveSessions();});}
      else if(ev.kind==='seat_update'){liveSoon(function(){if(sessionData)refreshActiveSessions();});}
      else if(ev.kind==='announcement'){Live.feed('\uD83D\uDCE2 '+d.by+': '+d.text);showToast('Librarian: '+d.text);}
      else if(ev.kind==='away_warning'||ev.kind==='end_warning'){Live.feed('\u23F3 '+d.message+' ('+d.minutes_left+' min left)');showToast(d.message);}
      else if(ev.kind==='session_ended'){Live.feed('\u2139\uFE0F '+d.message);showToast(d.message);if(sessionData)resetToLogin();}
    }
  });
}
function stopLive(){Live.stop();var b=document.getElementById('live-box');if(b)b.style.display='none';}
var ACTIONS={sendReport:sendReport,confirmSeatInput:confirmSeatInput,confirmStillHere:confirmStillHere,doAway:doAway,doBack:doBack,doCheckin:doCheckin,doCheckout:doCheckout,doLogin:doLogin,getLocation:getLocation,goTab:goTab,reportIssue:reportIssue,selectFloor:selectFloor,setTheme:setTheme,startPomodoro:startPomodoro,stopPomodoro:stopPomodoro};
