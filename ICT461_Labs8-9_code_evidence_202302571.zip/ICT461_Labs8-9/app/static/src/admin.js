let chartOcc=null,chartHours=null,chartFloors=null;
const CHART_GOLD='rgba(201,168,76,';
const NAVY='rgba(13,31,60,';

function fmt(s){const h=Math.floor(s/3600),m=Math.floor((s%3600)/60),sc=s%60;if(h>0)return`${h}h ${m}m`;if(m>0)return`${m}m`;return`${sc}s`;}
function fmtTime(iso){return new Date(iso).toLocaleTimeString('en-ZM',{hour:'2-digit',minute:'2-digit'});}
function fmtDate(iso){return new Date(iso).toLocaleDateString('en-ZM',{weekday:'short',month:'short',day:'numeric'});}
function durLive(iso){return Math.floor((Date.now()-new Date(iso).getTime())/1000);}
function floorLabel(f){return{ground:'Ground',first:'1st Floor',second:'2nd Floor'}[f]||f||'—';}
function reasonBadge(r){
  if(!r||r==='manual')return'<span class="reason-badge reason-manual">Manual</span>';
  const labels={force_librarian:'Librarian',auto_away:'Away 20 min',auto_max_time:'3 hr limit',auto_inactive:'No response',auto_closing_time:'Closing time'};
  if(r==='force_librarian')return'<span class="reason-badge reason-force">Librarian</span>';
  return`<span class="reason-badge reason-auto">${labels[r]||'Auto'}</span>`;
}

async function loadStats(){
  const r=await fetch('/api/admin/stats');const d=await r.json();
  document.getElementById('s-current').textContent=d.current_occupancy;
  document.getElementById('s-today').textContent=d.sessions_today;
  document.getElementById('s-avg').textContent=d.avg_duration||'—';
  document.getElementById('s-total').textContent=d.total_sessions;
  document.getElementById('s-away').textContent=d.away_now??0;
  document.getElementById('s-auto').textContent=d.auto_releases_today??0;
  document.getElementById('s-oos').textContent=d.out_of_service??0;
  const pct=Math.min((d.current_occupancy/120)*100,100);
  const col=pct<50?'#16a34a':pct<80?'#d97706':'#dc2626';
  document.getElementById('cap-bar').style.cssText=`width:${pct}%;background:${col}`;
  document.getElementById('cap-label').textContent=`${d.current_occupancy}/120 · ${Math.round(pct)}%`;
}

async function loadActive(){
  const r=await fetch('/api/admin/active');const sessions=await r.json();
  document.getElementById('active-count').textContent=`(${sessions.length})`;
  const el=document.getElementById('active-list');
  if(!sessions.length){el.innerHTML='<div class="empty">No active sessions.</div>';return;}
  el.innerHTML=sessions.map(s=>`
    <div class="row-item">
      <div style="flex:1;min-width:0">
        <div class="row-name">${esc(s.full_name)}</div>
        <div class="row-meta">${esc(s.student_id)} · <span class="floor-badge">${floorLabel(s.floor)}</span> · Seat <strong>${esc(s.seat_number||'—')}</strong>${s.status==='away'?` · <span class="away-badge">Away ${Math.floor(durLive(s.away_since)/60)} min</span>`:''}</div>
      </div>
      <div style="text-align:right;flex-shrink:0">
        <div class="row-live">${fmt(durLive(s.check_in_time))}</div>
        <div class="row-time">${fmtTime(s.check_in_time)}</div>
        <button class="btn-vacant" data-click="markVacant" data-args="${esc(JSON.stringify([s.floor,s.seat_number]))}">Mark Vacant</button>
      </div>
    </div>`).join('');

  // Floor breakdown
  const counts={ground:0,first:0,second:0};
  sessions.forEach(s=>{if(s.floor&&counts[s.floor]!==undefined)counts[s.floor]++;});
  document.getElementById('floor-stats').innerHTML=Object.entries({ground:'Ground Floor',first:'1st Floor',second:'2nd Floor'}).map(([k,label])=>`
    <div style="text-align:center;background:var(--surface2);border-radius:8px;padding:12px">
      <div style="font-family:'Playfair Display',serif;font-size:24px;font-weight:700;color:var(--gold)">${counts[k]}</div>
      <div style="font-size:11px;color:var(--muted);margin-top:2px">${label}</div>
    </div>`).join('');
}

const post=(u,b)=>fetch(u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)}).then(r=>r.json());

async function markVacant(floor,seat){
  if(!confirm(`Mark seat ${seat} vacant? The student will be checked out.`))return;
  const d=await post('/api/admin/mark_vacant',{floor,seat_number:seat});
  if(d.success)refresh(); else alert(d.error||'Could not mark seat vacant.');
}

let seatFloor='ground';
function setSeatFloor(k){seatFloor=k;loadSeats();}
const FLOOR_NAMES={ground:'Ground Floor',first:'1st Floor',second:'2nd Floor'};
async function loadSeats(){
  document.getElementById('seat-tabs').innerHTML=Object.entries(FLOOR_NAMES).map(([k,l])=>
    `<button class="tab ${k===seatFloor?'on':''}" data-click="setSeatFloor" data-args="${esc(JSON.stringify([k]))}">${l}</button>`).join('');
  const r=await fetch('/api/admin/seats/'+seatFloor);const d=await r.json();
  if(!d.seats)return;
  document.getElementById('seat-grid').innerHTML=d.seats.map(s=>{
    const st=s.status||'free';
    const sub=st==='free'?'':st==='out_of_service'?'out':(s.full_name||'').split(' ')[0];
    const tip=st==='free'?'Free':st==='out_of_service'?('Out of service'+(s.reason?': '+s.reason:'')):`${s.full_name} (${s.student_id})${st==='away'?' – away':''}`;
    return `<div class="seat ${st}" title="${esc(tip)}" data-click="seatClick" data-args="${esc(JSON.stringify([s.id,st]))}">${esc(s.id)}<small>${esc(sub)}</small></div>`;
  }).join('');
}
async function seatClick(id,st){
  let d;
  if(st==='occupied'||st==='away'){
    if(!confirm(`Mark seat ${id} vacant? The student will be checked out.`))return;
    d=await post('/api/admin/mark_vacant',{floor:seatFloor,seat_number:id});
  }else if(st==='free'){
    const reason=prompt(`Take seat ${id} out of service. Reason (optional):`);
    if(reason===null)return;
    d=await post('/api/admin/out_of_service',{floor:seatFloor,seat_number:id,out:true,reason});
  }else{
    if(!confirm(`Restore seat ${id} to service?`))return;
    d=await post('/api/admin/out_of_service',{floor:seatFloor,seat_number:id,out:false});
  }
  if(d&&d.success)refresh(); else alert((d&&d.error)||'Action failed.');
}

async function loadHistory(){
  const r=await fetch('/api/admin/history');const hist=await r.json();
  document.getElementById('hist-count').textContent=`(${hist.length})`;
  const el=document.getElementById('hist-list');
  if(!hist.length){el.innerHTML='<div class="empty">No completed sessions yet.</div>';return;}
  el.innerHTML=hist.map(s=>`
    <div class="row-item">
      <div style="flex:1;min-width:0">
        <div class="row-name">${esc(s.full_name)}</div>
        <div class="row-meta">${esc(s.student_id)} · <span class="floor-badge">${floorLabel(s.floor)}</span> · ${fmtDate(s.check_in_time)}</div>
      </div>
      <div style="text-align:right;flex-shrink:0">
        <div class="row-dur">${s.duration}</div>
        <div class="row-time">${fmtTime(s.check_in_time)}–${fmtTime(s.check_out_time)}</div>
        ${reasonBadge(s.checkout_reason)}
      </div>
    </div>`).join('');
}

let Chart=null;
async function loadCharts(){
  const r=await fetch('/api/admin/chart_data',{cache:'no-store'});const d=await r.json();
  if(!Chart){Chart=(await import('./chart-lazy.js')).Chart;}

  // Occupancy over 7 days
  const octx=document.getElementById('chart-occupancy').getContext('2d');
  if(chartOcc)chartOcc.destroy();
  chartOcc=new Chart(octx,{type:'bar',data:{
    labels:d.occupancy_days.length?d.occupancy_days:['No data yet'],
    datasets:[{label:'Check-ins',data:d.occupancy_counts.length?d.occupancy_counts:[0],
      backgroundColor:CHART_GOLD+'0.7)',borderColor:CHART_GOLD+'1)',borderWidth:2,borderRadius:6}]
  },options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{stepSize:1},grid:{color:'rgba(0,0,0,0.05)'}},x:{grid:{display:false}}}}});

  // Active hours
  const hctx=document.getElementById('chart-hours').getContext('2d');
  if(chartHours)chartHours.destroy();
  const hourLabels=['12a','1','2','3','4','5','6','7','8','9','10','11','12p','1','2','3','4','5','6','7','8','9','10','11'];
  chartHours=new Chart(hctx,{type:'line',data:{
    labels:hourLabels,
    datasets:[{label:'Check-ins',data:d.active_hours,fill:true,
      backgroundColor:NAVY+'0.08)',borderColor:NAVY+'0.8)',borderWidth:2,
      pointBackgroundColor:CHART_GOLD+'1)',pointRadius:3,tension:0.4}]
  },options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{stepSize:1},grid:{color:'rgba(0,0,0,0.05)'}},x:{grid:{display:false}}}}});

  // Sessions per floor
  const fctx=document.getElementById('chart-floors').getContext('2d');
  if(chartFloors)chartFloors.destroy();
  const floorVals=Object.values(d.sessions_per_floor);
  chartFloors=new Chart(fctx,{type:'bar',data:{
    labels:Object.keys(d.sessions_per_floor),
    datasets:[{label:'Sessions',data:floorVals,
      backgroundColor:['rgba(201,168,76,0.8)','rgba(13,31,60,0.8)','rgba(22,163,74,0.8)'],
      borderRadius:8,borderSkipped:false}]
  },options:{indexAxis:'y',responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{beginAtZero:true,ticks:{stepSize:1},grid:{color:'rgba(0,0,0,0.05)'}},y:{grid:{display:false}}}}});
}

async function logout(){await fetch('/api/admin/logout',{method:'POST'});window.location.href='/admin';}

async function refresh(){
  await Promise.all([loadStats(),loadActive(),loadHistory(),loadCharts(),loadSeats()]);
  document.getElementById('last-refresh').textContent=`Last updated: ${new Date().toLocaleTimeString('en-ZM')} · Mulungushi University Library`;
}

refresh();
// Lab 8: refresh when the server pushes an event; fall back to polling only while the live channel is down
var liveT=null;function liveRefresh(){clearTimeout(liveT);liveT=setTimeout(refresh,250);}
setInterval(function(){if(!Live.connected())refresh();},10000);
setInterval(refresh,120000);
function sendAnnounce(){var el=document.getElementById('live-announce-text'),t=el.value.trim();if(!t)return;if(Live.send({type:'announce',text:t}))el.value='';else Live.feed('Not connected: announcement not sent');}
Live.start({
  onError:function(m){Live.feed('Rejected by server: '+m);},
  onEvent:function(ev){var d=ev.data||{};
    if(ev.kind==='session_started'){Live.feed('\u2795 '+d.full_name+' checked in at '+d.seat_number);liveRefresh();}
    else if(ev.kind==='session_ended'){Live.feed('\u2796 '+d.full_name+' left '+d.seat_number+' ('+d.reason+')');liveRefresh();}
    else if(ev.kind==='issue_report'){Live.feed('\u26A0\uFE0F Seat '+d.seat+' ('+d.name+'): '+d.text);}
    else if(ev.kind==='announcement'){Live.feed('\uD83D\uDCE2 Sent: '+d.text);}
    else if(ev.kind==='status_changed'||ev.kind==='occupancy'){liveRefresh();}
  }});

// Lab 6: contextual output encoding for every value placed into innerHTML / attributes
function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
// Lab 6: CSP-safe event delegation (no inline on* attributes). Only registered actions can run.
document.addEventListener('click',function(e){var el=e.target.closest('[data-click]');if(!el)return;var fn=ACTIONS[el.getAttribute('data-click')];if(fn){var a=[];try{a=JSON.parse(el.getAttribute('data-args')||'[]');}catch(x){}fn.apply(null,a);}});
var ACTIONS={sendAnnounce:sendAnnounce,logout:logout,markVacant:markVacant,seatClick:seatClick,setSeatFloor:setSeatFloor};
