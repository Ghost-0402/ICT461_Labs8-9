// Only the Chart.js parts the admin dashboard uses (bar + line). Tree-shaken and loaded lazily.
import {Chart,BarController,BarElement,LineController,LineElement,PointElement,CategoryScale,LinearScale,Tooltip,Legend,Filler} from 'chart.js';
Chart.register(BarController,BarElement,LineController,LineElement,PointElement,CategoryScale,LinearScale,Tooltip,Legend,Filler);
export {Chart};
