/* Lab 8 / Task 4: resilient WebSocket client.
   - status indicator: Connected / Reconnecting / Offline
   - exponential backoff with jitter: ceiling 1s, 2s, 4s, 8s, 16s, 30s (cap); the wait is a random value between 50% and 100% of the ceiling
   - after every reconnect it asks the server for the events it missed (sync with the last event id it saw)
   Only textContent is used to show server data (no innerHTML), so event text can never run as markup. */
(function (root) {
  'use strict';
  var META = document.querySelector('meta[name="ws-port"]');
  var ROLE = document.querySelector('meta[name="ws-role"]');
  function wsUrl() { return (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.hostname + ':' + (META ? META.content : '5050') + '/api/ws' + (ROLE ? '?as=' + ROLE.content : ''); }
  function stamp() { return new Date().toISOString().slice(11, 23); }
  function log() { var a = ['[live ' + stamp() + ']'].concat([].slice.call(arguments)); console.info.apply(console, a); }

  function ResilientSocket(o) {
    this.o = o; this.base = o.baseMs || 1000; this.cap = o.capMs || 30000; this.maxInitialFailures = o.maxInitialFailures || 5;
    this.attempt = 0; this.initFails = 0; this.everOpen = false; this.want = false; this.ws = null; this.timer = null; this.tick = null;
    this.lastId = null; this.state = 'idle';
    var self = this;
    window.addEventListener('offline', function () { if (self.want) { self._clear(); if (self.ws) try { self.ws.close(); } catch (e) {} self._set('offline', 'No network'); } });
    window.addEventListener('online', function () { if (self.want) { log('network is back, reconnecting now'); self.attempt = 0; self._connect(); } });
  }
  ResilientSocket.prototype._set = function (state, text) { this.state = state; if (this.o.onStatus) this.o.onStatus(state, text || ''); };
  ResilientSocket.prototype._clear = function () { clearTimeout(this.timer); clearInterval(this.tick); this.timer = this.tick = null; };
  ResilientSocket.prototype.delayFor = function (attempt) {
    var ceil = Math.min(this.cap, this.base * Math.pow(2, attempt));
    return { ceil: ceil, wait: Math.round(ceil / 2 + Math.random() * ceil / 2) };          // equal jitter
  };
  ResilientSocket.prototype.open = function () { this.want = true; this.attempt = 0; this.initFails = 0; this._connect(); };
  ResilientSocket.prototype.close = function () { this.want = false; this._clear(); if (this.ws) try { this.ws.close(1000); } catch (e) {} this._set('idle', ''); };
  ResilientSocket.prototype.send = function (obj) { if (this.ws && this.ws.readyState === 1) { this.ws.send(JSON.stringify(obj)); return true; } return false; };
  ResilientSocket.prototype._connect = function () {
    var self = this; this._clear();
    if (navigator.onLine === false) { this._set('offline', 'No network'); this.timer = setTimeout(function () { self._connect(); }, 2000); return; }   // keep checking
    if (this.attempt > 0) this._set('reconnecting', 'Reconnecting...');
    var ws; try { ws = new WebSocket(wsUrl()); } catch (e) { return this._retry(); }
    this.ws = ws;
    ws.onopen = function () { log('socket open'); };
    ws.onmessage = function (m) {
      var f; try { f = JSON.parse(m.data); } catch (e) { return; }
      if (f.type === 'hello') {
        self.everOpen = true; self.attempt = 0; self.initFails = 0; self._set('connected', 'Live');
        if (self.lastId === null) self.lastId = f.latest_id;                       // first connection: nothing to replay
        else { log('reconnected, requesting events after id', self.lastId); ws.send(JSON.stringify({ type: 'sync', last_id: self.lastId })); }
      } else if (f.type === 'event' && f.id != null && (self.lastId === null || f.id > self.lastId)) { self.lastId = f.id; }
      if (self.o.onFrame) self.o.onFrame(f);
    };
    ws.onerror = function () { log('socket error'); };
    ws.onclose = function (ev) {
      if (ws !== self.ws || !self.want) return;
      log('socket closed code=' + ev.code + (self.everOpen ? '' : ' (never connected)'));
      if (!self.everOpen && ++self.initFails >= self.maxInitialFailures) { self._set('offline', 'Could not connect'); log('giving up after', self.initFails, 'failed attempts (sign in first)'); return; }
      if (self.o.shouldRetry && !self.o.shouldRetry()) { self._set('offline', 'Signed out'); return; }
      self._retry();
    };
  };
  ResilientSocket.prototype._retry = function () {
    var self = this, d = this.delayFor(this.attempt), n = ++this.attempt, until = Date.now() + d.wait;
    log('reconnect #' + n + ' in ' + (d.wait / 1000).toFixed(2) + 's (ceiling ' + (d.ceil / 1000) + 's, jittered)');
    this._set('reconnecting', 'Reconnecting in ' + Math.ceil(d.wait / 1000) + 's');
    this.tick = setInterval(function () { self._set('reconnecting', 'Reconnecting in ' + Math.max(0, Math.ceil((until - Date.now()) / 1000)) + 's'); }, 1000);
    this.timer = setTimeout(function () { self._connect(); }, d.wait);
  };

  var sock = null, feedMax = 30;
  var LABELS = { connected: 'Live', reconnecting: 'Reconnecting', offline: 'Offline', idle: 'Not connected' };
  function setBadge(state, text) {
    var b = document.getElementById('ws-badge'); if (!b) return;
    b.setAttribute('data-state', state); b.textContent = '● ' + (text && state !== 'connected' ? text : LABELS[state]);
  }
  function feedAdd(text) {
    var f = document.getElementById('live-feed'); if (!f) return;
    var empty = f.querySelector('.live-empty'); if (empty) empty.remove();
    var li = document.createElement('div'); li.className = 'live-item';
    var t = document.createElement('span'); t.className = 'live-time'; t.textContent = new Date().toLocaleTimeString('en-ZM', { hour: '2-digit', minute: '2-digit' });
    var m = document.createElement('span'); m.textContent = ' ' + text;
    li.appendChild(t); li.appendChild(m); f.insertBefore(li, f.firstChild);
    while (f.children.length > feedMax) f.removeChild(f.lastChild);
  }
  var Live = {
    start: function (opts) {                       // opts: {onEvent(ev), onError(msg), shouldRetry()}
      if (sock) sock.close();
      sock = new ResilientSocket({ onStatus: function (s, t) { setBadge(s, t); if (opts.onStatus) opts.onStatus(s); },
        shouldRetry: opts.shouldRetry,
        onFrame: function (f) {
          if (f.type === 'event') opts.onEvent(f);
          else if (f.type === 'error' && opts.onError) opts.onError(f.message || f.code);
          else if (f.type === 'synced' && f.count) feedAdd('Caught up: ' + f.count + ' missed update(s)');
        } });
      sock.open(); return sock;
    },
    stop: function () { if (sock) sock.close(); sock = null; setBadge('idle', ''); },
    send: function (o) { return sock ? sock.send(o) : false; },
    connected: function () { return !!sock && sock.state === 'connected'; },
    debugDrop: function () { if (sock && sock.ws) sock.ws.close(); },       // test hook: closes the socket like a network drop
    feed: feedAdd, ResilientSocket: ResilientSocket
  };
  root.Live = Live;
})(window);
