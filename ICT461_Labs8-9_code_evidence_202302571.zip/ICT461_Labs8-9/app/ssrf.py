"""Lab 6 / A10: SSRF guard for any future server-side fetch (for example a profile photo or a reading-list URL).
The audit found no endpoint that fetches a user-supplied URL today; this is the preventive control to use if one is added."""
import ipaddress, socket
from urllib.parse import urlparse

ALLOWED_HOSTS = {"ieeexplore.ieee.org", "link.springer.com", "scholar.google.com", "www.researchgate.net"}

class UnsafeURL(ValueError): pass

def validate_url(url, allowed_hosts=ALLOWED_HOSTS):
    """Return the URL if it is safe to fetch, otherwise raise UnsafeURL."""
    p = urlparse(url)
    if p.scheme != "https": raise UnsafeURL("only https is allowed")
    if p.username or p.password: raise UnsafeURL("credentials in the URL are not allowed")
    host = (p.hostname or "").lower()
    if host not in allowed_hosts: raise UnsafeURL("host is not on the allow-list")
    if p.port not in (None, 443): raise UnsafeURL("only port 443 is allowed")
    try: infos = socket.getaddrinfo(host, 443, proto=socket.IPPROTO_TCP)
    except socket.gaierror: raise UnsafeURL("host does not resolve")
    for info in infos:   # resolve first, then check the real addresses (stops DNS tricks and decimal/hex IPs)
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast or ip.is_unspecified:
            raise UnsafeURL(f"resolves to a non-public address ({ip})")
    return url

def safe_fetch(url, **kw):
    """requests wrapper: validated URL, no redirects (a redirect could point back inside), short timeout, size cap."""
    import requests
    validate_url(url)
    r = requests.get(url, allow_redirects=False, timeout=(3, 5), stream=True, **kw)
    body = r.raw.read(1_000_001, decode_content=True)
    if len(body) > 1_000_000: raise UnsafeURL("response too large")
    return r.status_code, body
