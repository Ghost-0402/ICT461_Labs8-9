"""Contract tests: every response is checked against openapi.yaml (status, content type, body schema, documented headers)."""
import json, os, sys, yaml, requests
from jsonschema import Draft202012Validator
ROOT = os.path.join(os.path.dirname(__file__), "..")
SPEC = yaml.safe_load(open(os.path.join(ROOT, "openapi.yaml"), encoding="utf-8"))
BASE = "https://localhost:8443"; CA = os.path.join(ROOT, "certs", "ca.pem")
S = requests.Session(); S.trust_env = False; S.verify = CA
results, covered = [], set()

def resolve(o):
    if isinstance(o, dict) and "$ref" in o:
        n = o["$ref"].split("/"); d = SPEC
        for p in n[1:]: d = d[p]
        return resolve(d)
    return o

def check(name, method, path, status, spec_path, body=None, raw=None, session=None, headers=None, expect_headers=()):
    s = session or S
    kw = {"headers": dict(headers or {})}
    if body is not None: kw["json"] = body
    if raw is not None: kw["data"] = raw; kw["headers"].setdefault("Content-Type", "application/json")
    r = s.request(method, BASE + path, **kw)
    ok, why = r.status_code == status, ""
    op = SPEC["paths"][spec_path][method.lower()]
    resp = resolve(op["responses"].get(str(status)))
    if resp is None: ok, why = False, f"{status} not documented"
    elif ok and resp.get("content"):
        ctype, media = next(iter(resp["content"].items()))
        if ctype not in r.headers.get("Content-Type", ""): ok, why = False, "content-type " + r.headers.get("Content-Type", "")
        else:
            sch = resolve(media["schema"]); ref = media["schema"].get("$ref", "")
            v = Draft202012Validator({"$ref": ref, "components": SPEC["components"]}) if ref else Draft202012Validator(sch)
            errs = list(v.iter_errors(r.json()))
            if errs: ok, why = False, errs[0].message
    if ok:
        for h in expect_headers:
            if h not in r.headers: ok, why = False, f"missing header {h}"
    covered.add((spec_path, method.upper()))
    results.append({"check": name, "method": method, "path": path, "expected": status, "got": r.status_code, "pass": ok, "why": why})
    print(("PASS" if ok else "FAIL"), name, method, path, r.status_code, why); return r

sid = "202309" + str(abs(hash(os.urandom(4))) % 1000).zfill(3)
good = {"student_id": sid, "full_name": "Contract Tester", "password": "LongEnough1"}
RL = ("X-RateLimit-Limit", "X-RateLimit-Remaining", "X-RateLimit-Reset")
check("register ok", "POST", "/api/v1/users", 201, "/api/v1/users", good)
check("register duplicate", "POST", "/api/v1/users", 409, "/api/v1/users", good)
check("register missing fields", "POST", "/api/v1/users", 422, "/api/v1/users", {})
check("register bad types", "POST", "/api/v1/users", 422, "/api/v1/users", {**good, "student_id": 123})
check("register extra field", "POST", "/api/v1/users", 422, "/api/v1/users", {**good, "is_admin": True})
check("register malformed JSON", "POST", "/api/v1/users", 400, "/api/v1/users", raw='{"student_id": ')
r = S.post(BASE + "/api/v1/users", data="x=1", headers={"Content-Type": "text/plain"}); results.append({"check": "register wrong content-type", "method": "POST", "path": "/api/v1/users", "expected": 415, "got": r.status_code, "pass": r.status_code == 415, "why": ""}); print("PASS" if r.status_code == 415 else "FAIL", "415 check")
check("login wrong password", "POST", "/api/v1/auth/login", 401, "/api/v1/auth/login", {"student_id": sid, "password": "wrong-password"})
check("login bad schema", "POST", "/api/v1/auth/login", 422, "/api/v1/auth/login", {"student_id": "abc"})
a = requests.Session(); a.trust_env = False; a.verify = CA
r = check("login ok", "POST", "/api/v1/auth/login", 200, "/api/v1/auth/login", {"student_id": sid, "password": "LongEnough1"}, session=a)
sc = r.headers.get("Set-Cookie", ""); flags = all(x in sc for x in ("HttpOnly", "Secure", "SameSite=Strict"))
results.append({"check": "cookie flags HttpOnly+Secure+SameSite=Strict", "method": "-", "path": "Set-Cookie", "expected": "flags", "got": sc.split(";", 1)[1].strip() if ";" in sc else sc, "pass": flags, "why": ""}); print("PASS" if flags else "FAIL", "cookie flags")
check("me without cookie", "GET", "/api/v1/auth/me", 401, "/api/v1/auth/me")
check("me with session", "GET", "/api/v1/auth/me", 200, "/api/v1/auth/me", session=a)
check("seats ok", "GET", "/api/v1/seats/ground", 200, "/api/v1/seats/{floor}")
check("seats bad floor", "GET", "/api/v1/seats/roof", 404, "/api/v1/seats/{floor}")
check("occupancy + rate headers", "GET", "/api/v1/occupancy", 200, "/api/v1/occupancy", expect_headers=RL)
check("checkin without session", "POST", "/api/v1/checkins", 401, "/api/v1/checkins", {"floor": "ground", "seat_number": "G1", "planned_hours": 1})
check("checkin cross-field rule", "POST", "/api/v1/checkins", 422, "/api/v1/checkins", {"floor": "ground", "seat_number": "F12", "planned_hours": 9}, session=a)
check("checkin ok", "POST", "/api/v1/checkins", 201, "/api/v1/checkins", {"floor": "ground", "seat_number": "G" + str(20 + int(sid[-2:]) % 15), "planned_hours": 2, "needs": ["power"]}, session=a)
check("checkin again conflict", "POST", "/api/v1/checkins", 409, "/api/v1/checkins", {"floor": "first", "seat_number": "F1", "planned_hours": 1}, session=a)
check("cross-origin logout blocked", "POST", "/api/v1/auth/logout", 403, "/api/v1/auth/logout", session=a, headers={"Origin": "https://evil.example"})
check("release seat", "DELETE", "/api/v1/checkins/current", 204, "/api/v1/checkins/current", session=a)
check("release again", "DELETE", "/api/v1/checkins/current", 404, "/api/v1/checkins/current", session=a)
old = a.cookies.get("sessionId")
check("logout", "POST", "/api/v1/auth/logout", 204, "/api/v1/auth/logout", session=a)
b = requests.Session(); b.trust_env = False; b.verify = CA; b.cookies.set("sessionId", old)
check("revoked cookie replay", "GET", "/api/v1/auth/me", 401, "/api/v1/auth/me", session=b)
ops = {(p, m.upper()) for p, v in SPEC["paths"].items() for m in v}
passed = sum(x["pass"] for x in results)
print(f"\n{passed}/{len(results)} checks passed; operations covered {len(covered & ops)}/{len(ops)}")
json.dump({"passed": passed, "total": len(results), "operations_covered": len(covered & ops), "operations": len(ops), "results": results},
          open(os.path.join(ROOT, "..", "evidence", "contract_results.json"), "w"), indent=1)
sys.exit(0 if passed == len(results) else 1)
