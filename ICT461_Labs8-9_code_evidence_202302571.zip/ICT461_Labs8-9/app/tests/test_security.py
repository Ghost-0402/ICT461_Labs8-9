"""Lab 6 security regression tests (run: python -m unittest tests.test_security -v from the app folder)."""
import ast, os, re, sqlite3, subprocess, sys, tempfile, unittest
from unittest import mock
APP = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
sys.path.insert(0, APP)
import ssrf

class SqlInjection(unittest.TestCase):
    PAYLOAD = "' OR '1'='1"
    def setUp(self):
        self.c = sqlite3.connect(":memory:")
        self.c.execute("create table users(student_id text, full_name text)")
        self.c.executemany("insert into users values (?,?)", [("202300001", "Alice"), ("202300002", "Bob")])
    def test_negative_control_concatenation_is_injectable(self):
        """Proves the test can detect the bug: the lecture's unsafe pattern returns every row."""
        rows = self.c.execute("SELECT * FROM users WHERE student_id = '" + self.PAYLOAD + "'").fetchall()
        self.assertEqual(len(rows), 2)
    def test_parameterised_query_treats_payload_as_data(self):
        rows = self.c.execute("SELECT * FROM users WHERE student_id = ?", (self.PAYLOAD,)).fetchall()
        self.assertEqual(rows, [])
    def test_no_runtime_built_sql_in_project_code(self):
        """AST scan: no f-string, % or + string passed to execute()/executescript() in project .py files."""
        bad = []
        for fn in os.listdir(APP):
            if not fn.endswith(".py"): continue
            tree = ast.parse(open(os.path.join(APP, fn), encoding="utf-8").read())
            for n in ast.walk(tree):
                if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr in ("execute", "executescript", "executemany") and n.args:
                    a = n.args[0]
                    if isinstance(a, (ast.JoinedStr, ast.BinOp)): bad.append(f"{fn}:{n.lineno}")
        self.assertEqual(bad, [], "dynamic SQL found: " + ", ".join(bad))

class Ssrf(unittest.TestCase):
    def blocked(self, url):
        with self.assertRaises(ssrf.UnsafeURL): ssrf.validate_url(url)
    def test_blocks_cloud_metadata(self): self.blocked("http://169.254.169.254/latest/meta-data/")
    def test_blocks_https_metadata_ip(self): self.blocked("https://169.254.169.254/")
    def test_blocks_localhost(self): self.blocked("https://localhost/admin")
    def test_blocks_loopback_decimal(self): self.blocked("https://2130706433/")
    def test_blocks_private_range(self): self.blocked("https://10.0.0.5/")
    def test_blocks_credentials_in_url(self): self.blocked("https://user:pw@ieeexplore.ieee.org/")
    def test_blocks_odd_port(self): self.blocked("https://ieeexplore.ieee.org:8443/")
    def test_blocks_http_scheme(self): self.blocked("http://ieeexplore.ieee.org/")
    def test_blocks_host_not_on_allow_list(self): self.blocked("https://evil.example/")
    def test_blocks_allowed_name_that_resolves_to_private_ip(self):
        fake = [(2, 1, 6, "", ("10.0.0.5", 443))]
        with mock.patch("ssrf.socket.getaddrinfo", return_value=fake): self.blocked("https://ieeexplore.ieee.org/")
    def test_allows_allowed_host_with_public_ip(self):
        fake = [(2, 1, 6, "", ("93.184.216.34", 443))]
        with mock.patch("ssrf.socket.getaddrinfo", return_value=fake):
            self.assertEqual(ssrf.validate_url("https://ieeexplore.ieee.org/x"), "https://ieeexplore.ieee.org/x")

class EnvValidation(unittest.TestCase):
    def run_cfg(self, env):
        code = "import config; config.load_settings(dotenv_path='/nonexistent'); print('STARTED')"
        e = {"PATH": os.environ["PATH"], **env}
        return subprocess.run([sys.executable, "-c", code], cwd=APP, env=e, capture_output=True, text=True)
    GOOD = {"MU_SECRET_KEY": "x" * 48 + "Q9", "MU_ADMIN_PIN": "S3cure-Pin-77", "APP_ENV": "production", "DATABASE_PATH": "library.db"}
    def test_halts_when_secrets_missing(self):
        r = self.run_cfg({}); self.assertEqual(r.returncode, 1); self.assertIn("MU_SECRET_KEY is missing", r.stderr); self.assertNotIn("STARTED", r.stdout)
    def test_halts_on_the_old_hardcoded_defaults(self):
        r = self.run_cfg({**self.GOOD, "MU_ADMIN_PIN": "MU2026"}); self.assertEqual(r.returncode, 1); self.assertIn("MU_ADMIN_PIN is invalid", r.stderr)
    def test_halts_on_short_secret_key(self):
        r = self.run_cfg({**self.GOOD, "MU_SECRET_KEY": "short"}); self.assertEqual(r.returncode, 1)
    def test_starts_with_valid_environment(self):
        r = self.run_cfg(self.GOOD); self.assertEqual(r.returncode, 0); self.assertIn("STARTED", r.stdout)

class NoSecretsInSource(unittest.TestCase):
    def test_no_hardcoded_defaults_in_python_source(self):
        for fn in os.listdir(APP):
            if fn.endswith(".py") and fn not in ("config.py",):
                s = open(os.path.join(APP, fn), encoding="utf-8").read()
                self.assertNotIn("mu-library-secret-2026", s, fn); self.assertNotIn("MU2026", s, fn)

if __name__ == "__main__": unittest.main(verbosity=2)
