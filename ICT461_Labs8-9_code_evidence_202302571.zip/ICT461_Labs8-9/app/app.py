from config import load_settings
SETTINGS = load_settings()   # Lab 6: halts start-up if any secret is missing or weak
from flask import Flask, request, jsonify, render_template, session, make_response
import hmac
import database
database.DB_PATH = SETTINGS["DATABASE_PATH"]
from database import (init_db, checkin_student, checkout_student, get_active_sessions,
                      get_session_history, get_stats, is_already_checked_in, is_seat_taken,
                      get_occupied_seats, cleanup_expired_sessions, update_activity, get_chart_data,
                      set_away, set_back, get_session, get_seat_states, mark_seat_vacant,
                      set_out_of_service, restore_seat, is_seat_out_of_service,
                      MAX_SESSION_MINUTES, AWAY_LIMIT_MINUTES, PING_INTERVAL_MINUTES,
                      PING_GRACE_MINUTES, FLOORS)
from gps_utils import is_inside_library
import os, re, threading, time
from validation import validate_checkin
from api_v1 import init_api, rate_limit, problem as problem_v1
from ownership import init_ownership, issue as issue_token, owns, revoke as revoke_token, COOKIE as SEAT_COOKIE
from secure_http import init_secure_http
import realtime, ws_server
from ws_schemas import validate_frame

app = Flask(__name__)
# Set these as environment variables in real use; the defaults are for local development only.
app.secret_key = SETTINGS["MU_SECRET_KEY"]
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SECURE=True, SESSION_COOKIE_SAMESITE="Strict")

LIBRARY_CAPACITY = 120
ADMIN_PIN = SETTINGS["MU_ADMIN_PIN"]

init_db()
init_api(app)
init_ownership()
init_secure_http(app)
from perf import init_perf
init_perf(app)   # Lab 9: registered after secure_http so it runs first on the way out
realtime.init_events()
def _notify_and_invalidate(kind, **d):
    database.invalidate_aggregates()          # Lab 9: dashboard aggregates are cached for a few seconds; any change clears them
    realtime.on_domain_event(kind, **d)
database.notify = _notify_and_invalidate      # Lab 8: domain events feed the WebSocket layer
database.warn = realtime.warn_once

def format_duration(seconds):
    h, m, s = seconds//3600, (seconds%3600)//60, seconds%60
    if h > 0: return f"{h}h {m}m"
    if m > 0: return f"{m}m {s}s"
    return f"{s}s"

def validate_student_id(sid):
    return bool(re.fullmatch(r"\d{9}", sid.strip()))

# Background cleanup thread
def cleanup_loop():
    while True:
        time.sleep(30)  # check every 30 seconds (away limit is only 20 minutes)
        try:
            cleanup_expired_sessions()
        except Exception:
            pass

threading.Thread(target=cleanup_loop, daemon=True).start()

NAME_RE = re.compile(r"^[A-Za-z][A-Za-z .'\-]{1,59}$")
COURSE_RE = re.compile(r"^[A-Za-z0-9 .,&'()/\-]{1,80}$")

@app.before_request
def _legacy_origin_check():
    """CSRF defence for the legacy /api POST routes (the /api/v1 blueprint has its own copy of this check)."""
    if request.method == "POST" and request.path.startswith("/api/") and not request.path.startswith("/api/v1/"):
        origin = request.headers.get("Origin")
        if origin and origin != f"{request.scheme}://{request.host}":
            return jsonify({"success": False, "error": "Cross-origin requests are not allowed."}), 403

def require_owner(student_id):
    """Lab 6 / A01: only the browser that checked in (it holds the seat token) may act on that student ID."""
    if not owns(student_id, request.cookies.get(SEAT_COOKIE)):
        return jsonify({"success": False, "error": "Forbidden: this check-in does not belong to you."}), 403
    return None

# ─── Pages ──────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api-docs")
def api_docs(): return render_template("api_docs.html")

@app.route("/login")
def login_page(): return render_template("login.html")

@app.route("/portal")
def portal():
    from flask import redirect
    import security as sec
    if not sec.get_session_user(request.cookies.get(sec.SESSION_COOKIE)): return redirect("/login")
    return render_template("portal.html")

@app.route("/admin")
def admin():
    if not session.get("admin_logged_in"):
        return render_template("admin_login.html")
    return render_template("admin.html")

# ─── Student API ─────────────────────────────────────
@app.route("/api/checkin", methods=["POST"])
def api_checkin():
    data = request.get_json(silent=True) or {}
    student_id  = data.get("student_id","").strip()
    full_name   = data.get("full_name","").strip()
    course      = data.get("course","Not specified").strip()
    floor       = data.get("floor","").strip()
    seat_number = data.get("seat_number","").strip()
    latitude    = data.get("latitude")
    longitude   = data.get("longitude")

    if not isinstance(data.get("student_id",""), str) or not isinstance(data.get("full_name",""), str):
        return jsonify({"success": False, "error": "Invalid input types."}), 400
    if not NAME_RE.fullmatch(full_name):
        return jsonify({"success": False, "error": "Name may contain letters, spaces, hyphens and apostrophes only."}), 400
    if not COURSE_RE.fullmatch(course):
        return jsonify({"success": False, "error": "Course contains characters that are not allowed."}), 400
    if not student_id or not full_name:
        return jsonify({"success": False, "error": "Student ID and Full Name are required."}), 400
    if not validate_student_id(student_id):
        return jsonify({"success": False, "error": "Student ID must be exactly 9 digits."}), 400
    if not floor or floor not in FLOORS:
        return jsonify({"success": False, "error": "Please select a floor."}), 400
    if not seat_number:
        return jsonify({"success": False, "error": "Please select a seat."}), 400
    if latitude is None or longitude is None:
        return jsonify({"success": False, "error": "GPS location is required. Please allow location access."}), 400

    gps = is_inside_library(float(latitude), float(longitude))
    if not gps["allowed"]:
        return jsonify({"success": False, "error": gps["message"], "distance_metres": gps["distance_metres"]}), 403

    active = get_active_sessions()
    if len(active) >= LIBRARY_CAPACITY:
        return jsonify({"success": False, "error": f"Library is at full capacity ({LIBRARY_CAPACITY} students)."}), 409
    if is_already_checked_in(student_id):
        return jsonify({"success": False, "error": "This Student ID is already checked in."}), 409
    if is_seat_out_of_service(floor, seat_number):
        return jsonify({"success": False, "error": f"Seat {seat_number} is out of service. Please choose another."}), 409
    if is_seat_taken(floor, seat_number):
        return jsonify({"success": False, "error": f"Seat {seat_number} is already occupied. Please choose another."}), 409

    result = checkin_student(student_id, full_name, course, floor, seat_number, latitude, longitude)
    if not result["success"]:
        return jsonify(result), 409

    resp = jsonify({
        "success": True,
        "message": f"Welcome, {full_name.split()[0]}!",
        "check_in_time": result["check_in_time"],
        "student_id": student_id,
        "full_name": full_name,
        "course": course,
        "floor": floor,
        "floor_label": FLOORS[floor]["label"],
        "seat_number": seat_number,
        "occupancy": len(active) + 1,
        "capacity": LIBRARY_CAPACITY,
        "ping_interval_minutes": PING_INTERVAL_MINUTES,
        "ping_grace_minutes": PING_GRACE_MINUTES,
        "max_session_minutes": MAX_SESSION_MINUTES,
        "away_limit_minutes": AWAY_LIMIT_MINUTES,
    })
    resp.set_cookie(SEAT_COOKIE, issue_token(student_id), max_age=MAX_SESSION_MINUTES*60, httponly=True,
                    secure=True, samesite="Strict", path="/api")
    return resp


@app.route("/api/checkout", methods=["POST"])
def api_checkout():
    data = request.get_json(silent=True) or {}
    student_id = data.get("student_id","").strip()
    if not student_id:
        return jsonify({"success": False, "error": "Student ID required."}), 400
    denied = require_owner(student_id)
    if denied: return denied
    result = checkout_student(student_id, reason="manual")
    revoke_token(student_id)
    if not result["success"]:
        return jsonify(result), 404
    return jsonify({"success": True, "message": "Checked out successfully!", "duration": format_duration(result["duration_seconds"])})


@app.route("/api/activity", methods=["POST"])
def api_activity():
    data = request.get_json(silent=True) or {}
    student_id = data.get("student_id","").strip()
    denied = require_owner(student_id)
    if denied: return denied
    if update_activity(student_id):
        return jsonify({"success": True})
    return jsonify({"success": False, "error": "Session not found — you may have been auto-checked out."}), 404


@app.route("/api/away", methods=["POST"])
def api_away():
    """Student taps 'Step away': the seat is held for AWAY_LIMIT_MINUTES."""
    student_id = (request.get_json(silent=True) or {}).get("student_id", "").strip()
    denied = require_owner(student_id)
    if denied: return denied
    result = set_away(student_id)
    return jsonify(result), (200 if result["success"] else 404)


@app.route("/api/back", methods=["POST"])
def api_back():
    """Student taps 'I'm back'."""
    student_id = (request.get_json(silent=True) or {}).get("student_id", "").strip()
    denied = require_owner(student_id)
    if denied: return denied
    result = set_back(student_id)
    return jsonify(result), (200 if result["success"] else 404)


@app.route("/api/session_status/<student_id>")
def api_session_status(student_id):
    """The student's page polls this to learn if its seat was released."""
    denied = require_owner(student_id)
    if denied: return denied
    s = get_session(student_id)
    if not s:
        return jsonify({"active": False})
    return jsonify({"active": True, "status": s.get("status") or "present",
                    "away_since": s.get("away_since"), "check_in_time": s["check_in_time"]})


@app.route("/api/seats/<floor>")
def api_seats(floor):
    if floor not in FLOORS:
        return jsonify({"error": "Invalid floor"}), 400
    states = get_seat_states(floor)
    info = FLOORS[floor]
    seats = []
    for i in range(1, info["seats"] + 1):
        seat_id = f"{info['prefix']}{i}"
        status = states.get(seat_id, {}).get("status", "free")
        seats.append({"id": seat_id, "number": i, "status": status,
                      "occupied": status != "free"})  # 'occupied' kept for older clients
    return jsonify({"floor": floor, "label": info["label"], "seats": seats})


@app.route("/api/occupancy")
def api_occupancy():
    active = get_active_sessions()
    floor_counts = {"ground": 0, "first": 0, "second": 0}
    for s in active:
        f = s.get("floor")
        if f in floor_counts:
            floor_counts[f] += 1
    return jsonify({
        "current": len(active), "capacity": LIBRARY_CAPACITY,
        "percentage": round((len(active)/LIBRARY_CAPACITY)*100, 1),
        "available": LIBRARY_CAPACITY - len(active),
        "floors": floor_counts,
    })


@app.route("/api/active_sessions")
def api_active_sessions():
    """Public list: no student numbers, no coordinates, names shortened (data minimisation)."""
    token = request.cookies.get(SEAT_COOKIE)
    out = []
    for s in get_active_sessions():
        first = (s.get("full_name") or "Student").split()
        out.append({"full_name": first[0] + (" " + first[-1][0] + "." if len(first) > 1 else ""),
                    "floor": s.get("floor"), "seat_number": s.get("seat_number"),
                    "check_in_time": s.get("check_in_time"), "is_me": owns(s["student_id"], token)})
    return jsonify(out)


# ─── Admin API ───────────────────────────────────────
@app.route("/api/admin/login", methods=["POST"])
def admin_login():
    limited = rate_limit("auth")          # Lab 6 / A07: slow down PIN guessing
    if limited: return limited
    data = request.get_json(silent=True) or {}
    pin = data.get("pin")
    if isinstance(pin, str) and hmac.compare_digest(pin.encode(), ADMIN_PIN.encode()):
        session.clear()                   # new session on privilege change (stops fixation)
        session["admin_logged_in"] = True
        return jsonify({"success": True})
    return jsonify({"success": False, "error": "Incorrect PIN."}), 401


@app.route("/api/admin/logout", methods=["POST"])
def admin_logout():
    session.pop("admin_logged_in", None)
    return jsonify({"success": True})


@app.route("/api/admin/announce", methods=["POST"])
def admin_announce():
    """HTTP twin of the WebSocket 'announce' frame (same schema, same persistence). Works while the live channel is down."""
    if not session.get("admin_logged_in"):
        return jsonify({"error": "Unauthorized"}), 401
    frame = {"type": "announce", "text": (request.get_json(silent=True) or {}).get("text")}
    why = validate_frame(frame)
    if why: return jsonify({"success": False, "error": "Invalid announcement (" + why + ")"}), 400
    e = realtime.publish(realtime.ROOM_ALL, "announcement", {"text": frame["text"], "by": "Librarian"})
    return jsonify({"success": True, "id": e["id"]})


@app.route("/api/admin/ws_stats")
def admin_ws_stats():
    if not session.get("admin_logged_in"):
        return jsonify({"error": "Unauthorized"}), 401
    return jsonify(ws_server.hub.snapshot() if ws_server.hub else {"connected": 0})


@app.route("/api/admin/stats")
def admin_stats():
    if not session.get("admin_logged_in"):
        return jsonify({"error": "Unauthorized"}), 401
    stats = get_stats()
    stats["avg_duration"] = format_duration(stats["avg_duration_seconds"])
    return jsonify(stats)


@app.route("/api/admin/history")
def admin_history():
    if not session.get("admin_logged_in"):
        return jsonify({"error": "Unauthorized"}), 401
    try:                                                    # Lab 9: pagination, validated and clamped
        page = max(1, int(request.args.get("page", 1))); size = min(200, max(1, int(request.args.get("page_size", 50))))
    except ValueError:
        return jsonify({"error": "page and page_size must be integers"}), 400
    history = get_session_history(limit=size, offset=(page - 1) * size)
    for s in history:
        s["duration"] = format_duration(s["duration_seconds"])
        s.pop("latitude", None); s.pop("longitude", None)
    resp = jsonify(history); resp.headers["X-Page"] = str(page); resp.headers["X-Page-Size"] = str(size)
    return resp


@app.route("/api/admin/active")
def admin_active():
    if not session.get("admin_logged_in"):
        return jsonify({"error": "Unauthorized"}), 401
    return jsonify(get_active_sessions())


@app.route("/api/admin/force_checkout", methods=["POST"])
def admin_force_checkout():
    if not session.get("admin_logged_in"):
        return jsonify({"error": "Unauthorized"}), 401
    data = request.get_json(silent=True) or {}
    student_id = str(data.get("student_id","")).strip()
    result = checkout_student(student_id, reason="force_librarian")
    revoke_token(student_id)
    return jsonify(result)


@app.route("/api/admin/seats/<floor>")
def admin_seats(floor):
    """Full seat map for one floor, including who holds each seat."""
    if not session.get("admin_logged_in"):
        return jsonify({"error": "Unauthorized"}), 401
    if floor not in FLOORS:
        return jsonify({"error": "Invalid floor"}), 400
    states = get_seat_states(floor)
    info = FLOORS[floor]
    seats = []
    for i in range(1, info["seats"] + 1):
        seat_id = f"{info['prefix']}{i}"
        st = states.get(seat_id, {"status": "free"})
        seats.append({"id": seat_id, "number": i, **st})
    return jsonify({"floor": floor, "label": info["label"], "seats": seats})


@app.route("/api/admin/mark_vacant", methods=["POST"])
def admin_mark_vacant():
    if not session.get("admin_logged_in"):
        return jsonify({"error": "Unauthorized"}), 401
    data = request.get_json() or {}
    floor, seat = data.get("floor", ""), data.get("seat_number", "")
    if floor not in FLOORS:
        return jsonify({"success": False, "error": "Invalid floor"}), 400
    result = mark_seat_vacant(floor, seat)
    return jsonify(result), (200 if result["success"] else 404)


@app.route("/api/admin/out_of_service", methods=["POST"])
def admin_out_of_service():
    if not session.get("admin_logged_in"):
        return jsonify({"error": "Unauthorized"}), 401
    data = request.get_json() or {}
    floor, seat = data.get("floor", ""), data.get("seat_number", "")
    if floor not in FLOORS:
        return jsonify({"success": False, "error": "Invalid floor"}), 400
    if data.get("out", True):
        result = set_out_of_service(floor, seat, data.get("reason", ""))
    else:
        result = restore_seat(floor, seat)
    return jsonify(result), (200 if result["success"] else 409)


@app.route("/api/admin/chart_data")
def admin_chart_data():
    if not session.get("admin_logged_in"):
        return jsonify({"error": "Unauthorized"}), 401
    return jsonify(get_chart_data())


# ─── Lab 3: dual-layer validation endpoint ───
def problem(status, title, detail, errors=None):
    """RFC 7807 problem details response (application/problem+json)."""
    body = {"type": "about:blank", "title": title, "status": status, "detail": detail,
            "instance": request.path}
    if errors:
        body["errors"] = errors
    resp = jsonify(body)
    resp.status_code = status
    resp.headers["Content-Type"] = "application/problem+json"
    return resp


@app.route("/lab3")
def lab3_page():
    return render_template("lab3_checkin.html")


@app.route("/api/lab3/checkin", methods=["POST"])
def api_lab3_checkin():
    if not request.is_json:
        return problem(415, "Unsupported Media Type", "Send the request with Content-Type: application/json.")
    if request.content_length and request.content_length > 8192:
        return problem(413, "Payload Too Large", "The request body must be under 8 KB.")
    payload = request.get_json(silent=True)
    if payload is None:
        return problem(400, "Bad Request", "The request body is not valid JSON.")

    clean, errors = validate_checkin(payload)
    if errors:
        return problem(422, "Unprocessable Entity", f"{len(errors)} field(s) failed server-side validation.", errors)

    sid, floor, seat = clean["student_id"], clean["floor"], clean["seat_number"]
    if is_already_checked_in(sid):
        return problem(409, "Conflict", "This Student ID is already checked in.", {"student_id": "Already checked in."})
    if is_seat_out_of_service(floor, seat):
        return problem(409, "Conflict", f"Seat {seat} is out of service.", {"seat_number": "This seat is out of service. Choose another."})
    if is_seat_taken(floor, seat):
        return problem(409, "Conflict", f"Seat {seat} is already occupied.", {"seat_number": "This seat is already occupied. Choose another."})

    result = checkin_student(sid, clean["full_name"], clean["course"], floor, seat, None, None)
    if not result["success"]:
        return problem(409, "Conflict", result["error"])
    return jsonify({"success": True, "message": "Checked in.", "check_in_time": result["check_in_time"],
                    "record": clean, "max_session_minutes": MAX_SESSION_MINUTES}), 201


if __name__ == "__main__":
    print("=" * 50)
    print("  Mulungushi University Library System v2")
    print("  Running at http://localhost:5000")
    print("  Rules: 3 hr session, 20 min away limit")
    print("=" * 50)
    # Lab 6 / A05: never run the Werkzeug debugger (remote code execution) or listen on every interface by default
    ws_server.start(app)          # Lab 8: WebSocket engine next to the HTTP server (same process, port WS_PORT)
    app.run(debug=(SETTINGS["APP_ENV"] == "development" and os.environ.get("FLASK_DEBUG") == "1"),
            host=os.environ.get("HOST", "127.0.0.1"), port=int(os.environ.get("PORT", "5000")))
