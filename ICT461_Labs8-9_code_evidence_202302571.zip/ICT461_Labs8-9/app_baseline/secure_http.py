"""Lab 6 / Task 3: strict CSP with a per-request nonce plus defence-in-depth headers (the Python counterpart of Helmet.js)."""
import os, re, secrets
from flask import g, request

WS_PORT = os.environ.get("WS_PUBLIC_PORT") or os.environ.get("WS_PORT", "5050")   # port browsers use (differs only behind a reverse proxy)
def _ws_sources():
    """Lab 8: allow connections to our own WebSocket port on the host the page was loaded from (nothing else)."""
    host = request.host.rsplit(":", 1)[0] if ":" in request.host else request.host
    if not re.fullmatch(r"[A-Za-z0-9.\-]{1,100}", host): return ""
    return f" ws://{host}:{WS_PORT} wss://{host}:{WS_PORT}"

def init_secure_http(app):
    @app.before_request
    def _nonce(): g.csp_nonce = secrets.token_urlsafe(16)
    @app.context_processor
    def _ctx(): return {"csp_nonce": g.get("csp_nonce", ""), "ws_port": WS_PORT}
    @app.after_request
    def _headers(resp):
        n = g.get("csp_nonce", "")
        resp.headers["Content-Security-Policy"] = (
            f"default-src 'self'; script-src 'self' 'nonce-{n}'; object-src 'none'; base-uri 'none'; "
            f"frame-ancestors 'none'; form-action 'self'; img-src 'self' data:; connect-src 'self'{_ws_sources()}; "
            f"style-src 'self' 'nonce-{n}' https://fonts.googleapis.com; style-src-attr 'unsafe-inline'; font-src https://fonts.gstatic.com")
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        resp.headers["Cross-Origin-Opener-Policy"] = "same-origin"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        if request.path.startswith(("/api", "/login", "/portal", "/admin")): resp.headers["Cache-Control"] = "no-store"
        return resp
