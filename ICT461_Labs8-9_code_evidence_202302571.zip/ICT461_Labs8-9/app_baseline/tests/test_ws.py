"""Lab 8 tests (run from the app folder:  python -m unittest tests.test_ws -v).  Needs: pip install websockets"""
import asyncio, base64, json, os, socket, sqlite3, sys, tempfile, time, unittest
APP = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
sys.path.insert(0, APP)
TMP = tempfile.mkdtemp()
def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p
WS_PORT = free_port()
os.environ.update({"MU_SECRET_KEY": "test-secret-key-for-unit-tests-0123456789abcdef", "MU_ADMIN_PIN": "Unit-Test-Pin-9", "APP_ENV": "development",
                   "DATABASE_PATH": os.path.join(TMP, "ws_test.db"), "WS_PORT": str(WS_PORT), "WS_HEARTBEAT_INTERVAL": "0.4",
                   "WS_HEARTBEAT_TIMEOUT": "0.4", "WS_ALLOWED_ORIGINS": "http://127.0.0.1:5000", "PORT": "5000"})
os.chdir(APP)
import websockets
from websockets.exceptions import InvalidStatus, ConnectionClosed
import app as appmod, database, ownership, realtime, ws_server
from ws_schemas import validate_frame
HUB = ws_server.start(appmod.app, port=WS_PORT)
ORIGIN = "http://127.0.0.1:5000"
URL = f"ws://127.0.0.1:{WS_PORT}/api/ws"

def make_student(sid, floor="ground", seat="G1"):
    database.checkin_student(sid, "Test Student", "BSc CS", floor, seat, None, None)
    return ownership.issue(sid)
def admin_cookie():
    return "session=" + appmod.app.session_interface.get_signing_serializer(appmod.app).dumps({"admin_logged_in": True})
def student_cookie(tok): return f"seatToken={tok}"
async def connect(cookie, origin=ORIGIN, **kw):
    return await websockets.connect(URL, additional_headers={"Cookie": cookie, **({"Origin": origin} if origin else {})}, compression=None, **kw)
async def recv_json(ws, timeout=2): return json.loads(await asyncio.wait_for(ws.recv(), timeout))
async def drain_until(ws, kind, timeout=3):
    end = time.time() + timeout
    while time.time() < end:
        f = await recv_json(ws, max(0.1, end - time.time()))
        if f.get("kind") == kind or f.get("type") == kind: return f
    raise AssertionError("no " + kind)

class Handshake(unittest.IsolatedAsyncioTestCase):
    async def test_no_cookie_is_401(self):
        with self.assertRaises(InvalidStatus) as cm: await connect("")
        self.assertEqual(cm.exception.response.status_code, 401)
    async def test_garbage_and_tampered_cookies_are_401(self):
        for ck in ("seatToken=notarealtoken", "session=abc.def.ghi", admin_cookie()[:-3] + "xyz"):
            with self.assertRaises(InvalidStatus) as cm: await connect(ck)
            self.assertEqual(cm.exception.response.status_code, 401, ck)
    async def test_foreign_origin_is_403_even_with_valid_cookie(self):
        tok = make_student("202300001")
        with self.assertRaises(InvalidStatus) as cm: await connect(student_cookie(tok), origin="https://evil.example")
        self.assertEqual(cm.exception.response.status_code, 403)
    async def test_wrong_path_is_404(self):
        with self.assertRaises(InvalidStatus) as cm:
            await websockets.connect(URL.replace("/api/ws", "/other"), additional_headers={"Cookie": ""})
        self.assertEqual(cm.exception.response.status_code, 404)
    async def test_student_and_admin_get_their_rooms(self):
        tok = make_student("202300002", "first", "F2")
        async with await connect(student_cookie(tok)) as ws:
            h = await recv_json(ws)
            self.assertEqual(h["type"], "hello"); self.assertEqual(h["role"], "student")
            self.assertEqual(h["rooms"], ["all", "floor:first", "user:202300002"])
        async with await connect(admin_cookie()) as ws:
            h = await recv_json(ws); self.assertEqual((h["role"], h["rooms"]), ("admin", ["admin", "all"]))
    async def test_connection_cap_429(self):
        tok = make_student("202300003")
        socks = [await connect(student_cookie(tok)) for _ in range(3)]
        try:
            with self.assertRaises(InvalidStatus) as cm: await connect(student_cookie(tok))
            self.assertEqual(cm.exception.response.status_code, 429)
        finally:
            for s in socks: await s.close()

class Rooms(unittest.IsolatedAsyncioTestCase):
    async def test_events_reach_only_authorised_rooms(self):
        a = make_student("202300010", "ground", "G10"); b = make_student("202300011", "first", "F10")
        async with await connect(student_cookie(a)) as wa, await connect(student_cookie(b)) as wb, await connect(admin_cookie()) as wad:
            for w in (wa, wb, wad): await recv_json(w)
            realtime.publish(realtime.floor_room("ground"), "seat_update", {"seat_id": "G5", "status": "occupied"}, persist=False)
            realtime.publish(realtime.user_room("202300010"), "away_warning", {"message": "back soon", "minutes_left": 4})
            realtime.publish(realtime.ROOM_ADMIN, "issue_report", {"student_id": "x", "name": "n", "seat": "G1", "text": "lamp"})
            got_a = [await recv_json(wa), await recv_json(wa)]
            self.assertEqual({e["kind"] for e in got_a}, {"seat_update", "away_warning"})
            got_ad = await recv_json(wad); self.assertEqual(got_ad["kind"], "issue_report")
            with self.assertRaises(asyncio.TimeoutError): await recv_json(wb, 0.5)     # other floor + other user + not admin: nothing
            with self.assertRaises(asyncio.TimeoutError): await recv_json(wa, 0.3)     # student never sees the admin-room report

class Frames(unittest.IsolatedAsyncioTestCase):
    def test_schema_accepts_and_rejects(self):
        ok = [{"type": "sync", "last_id": 0}, {"type": "report", "text": "Broken lamp at G7"}, {"type": "announce", "text": "Closing at 18:00"}]
        bad = [{"type": "sync"}, {"type": "sync", "last_id": -1}, {"type": "sync", "last_id": "1"}, {"type": "sync", "last_id": 1, "x": 1},
               {"type": "report", "text": "<script>alert(1)</script>"}, {"type": "report", "text": ""}, {"type": "report", "text": "a" * 201},
               {"type": "hack"}, {"text": "no type"}, [], "str", 5]
        for f in ok: self.assertIsNone(validate_frame(f), f)
        for f in bad: self.assertIsNotNone(validate_frame(f), f)
    async def test_invalid_frames_get_errors_then_close_1008(self):
        tok = make_student("202300020")
        async with await connect(student_cookie(tok)) as ws:
            await recv_json(ws)
            await ws.send("{not json"); self.assertEqual((await recv_json(ws))["code"], "invalid_json")
            await ws.send(json.dumps({"type": "report", "text": "<img src=x onerror=alert(1)>"})); self.assertEqual((await recv_json(ws))["code"], "invalid_frame")
            await ws.send(json.dumps({"type": "sync", "last_id": 0, "evil": True}))
            with self.assertRaises(ConnectionClosed) as cm:
                for _ in range(3): await recv_json(ws)
            self.assertEqual(cm.exception.rcvd.code, 1008)
    async def test_role_enforcement_student_cannot_announce(self):
        tok = make_student("202300021")
        async with await connect(student_cookie(tok)) as ws:
            await recv_json(ws); await ws.send(json.dumps({"type": "announce", "text": "free coffee"}))
            self.assertEqual((await recv_json(ws))["code"], "forbidden")
    async def test_binary_and_oversize_frames_closed(self):
        tok = make_student("202300022")
        async with await connect(student_cookie(tok)) as ws:
            await recv_json(ws); await ws.send(b"\x00\x01")
            with self.assertRaises(ConnectionClosed) as cm: await ws.recv()
            self.assertEqual(cm.exception.rcvd.code, 1003)
        tok = make_student("202300023")
        async with await connect(student_cookie(tok)) as ws:
            await recv_json(ws); await ws.send("x" * 5000)
            with self.assertRaises(ConnectionClosed) as cm: await ws.recv()
            self.assertEqual(cm.exception.rcvd.code, 1009)

class Persistence(unittest.IsolatedAsyncioTestCase):
    async def test_missed_events_replayed_after_reconnect_and_sql_payload_is_inert(self):
        tok = make_student("202300030")
        async with await connect(student_cookie(tok)) as ws:
            hello = await recv_json(ws); last = hello["latest_id"]
        # client is offline: three events happen
        realtime.publish(realtime.ROOM_ALL, "announcement", {"text": "Library closes early", "by": "Librarian"})
        realtime.publish(realtime.user_room("202300030"), "away_warning", {"message": "Return soon", "minutes_left": 3})
        realtime.publish(realtime.user_room("202399999"), "away_warning", {"message": "someone else", "minutes_left": 1})
        async with await connect(student_cookie(tok)) as ws:
            await recv_json(ws); await ws.send(json.dumps({"type": "sync", "last_id": last}))
            frames = [await recv_json(ws) for _ in range(3)]
            self.assertEqual([f["kind"] for f in frames[:2]], ["announcement", "away_warning"])
            self.assertEqual(frames[2]["type"], "synced"); self.assertEqual(frames[2]["count"], 2)       # other user's event never replayed
        c = sqlite3.connect(os.environ["DATABASE_PATH"]); n = c.execute("SELECT COUNT(*) FROM events WHERE id > ?", (last,)).fetchone()[0]; c.close()
        self.assertEqual(n, 3)
    async def test_injection_text_is_stored_as_data(self):
        payload = "'; DROP TABLE events;--"
        async with await connect(admin_cookie()) as ws:
            await recv_json(ws); await ws.send(json.dumps({"type": "announce", "text": payload}))
            self.assertEqual((await drain_until(ws, "ack"))["of"], "announce")
        c = sqlite3.connect(os.environ["DATABASE_PATH"])
        row = c.execute("SELECT payload FROM events WHERE kind='announcement' ORDER BY id DESC LIMIT 1").fetchone(); c.close()
        self.assertEqual(json.loads(row[0])["text"], payload)            # events table still exists and holds the payload verbatim
    async def test_report_reaches_admin_and_is_persisted(self):
        tok = make_student("202300031", "second", "S3")
        async with await connect(admin_cookie()) as wad, await connect(student_cookie(tok)) as ws:
            await recv_json(wad); await recv_json(ws)
            await ws.send(json.dumps({"type": "report", "text": "Broken lamp at S3"}))
            e = await drain_until(wad, "issue_report"); self.assertEqual(e["data"]["text"], "Broken lamp at S3")
            self.assertEqual(e["data"]["student_id"], "202300031")       # identity comes from the session, not from the client frame

class Heartbeat(unittest.IsolatedAsyncioTestCase):
    async def test_healthy_client_survives_and_pongs_counted(self):
        tok = make_student("202300040"); before = HUB.stats["pongs"]
        async with await connect(student_cookie(tok)) as ws:            # the library answers Ping automatically
            await recv_json(ws); await asyncio.sleep(1.5)
            self.assertGreaterEqual(HUB.stats["pongs"] - before, 2); await ws.ping()
    async def test_half_open_client_is_evicted(self):
        tok = make_student("202300041"); before_ev, before_n = HUB.stats["evicted"], len(HUB.clients)
        r, w = await asyncio.open_connection("127.0.0.1", WS_PORT)
        key = base64.b64encode(os.urandom(16)).decode()
        w.write((f"GET /api/ws HTTP/1.1\r\nHost: 127.0.0.1:{WS_PORT}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: {key}\r\n"
                 f"Sec-WebSocket-Version: 13\r\nOrigin: {ORIGIN}\r\nCookie: seatToken={tok}\r\n\r\n").encode()); await w.drain()
        head = await asyncio.wait_for(r.readuntil(b"\r\n\r\n"), 2); self.assertIn(b"101 Switching Protocols", head)
        await asyncio.sleep(0.2); self.assertEqual(len(HUB.clients), before_n + 1)
        await asyncio.sleep(1.6)                                          # interval 0.4s + timeout 0.4s, and we never answer
        self.assertEqual(HUB.stats["evicted"], before_ev + 1); self.assertEqual(len(HUB.clients), before_n)
        w.close()

if __name__ == "__main__": unittest.main()
