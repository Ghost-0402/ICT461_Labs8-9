// Lab 9 build: bundle + minify + tree-shake + code-split + content-hash. Output: app/static/dist + manifest.json
import {build} from 'esbuild';
import fs from 'node:fs'; import path from 'node:path';
const app = path.resolve('..','app'), out = path.join(app,'static','dist');
fs.rmSync(out,{recursive:true,force:true});
const cssPrefix = {'fonts.css':['fonts.css'],'index.css':['fonts.css','index.css'],'admin.css':['fonts.css','admin.css']};
const r = await build({
  entryPoints:{index:`${app}/static/src/index.js`, admin:`${app}/static/src/admin.js`, live:`${app}/static/js/live.js`},
  bundle:true, minify:true, format:'esm', splitting:true, treeShaking:true, target:['es2019'],
  outdir:out, entryNames:'[name]-[hash]', chunkNames:'chunks/[name]-[hash]', metafile:true, legalComments:'none',
  nodePaths:[path.resolve('node_modules')], logLevel:'warning',
});
const manifest={};
for (const [file,meta] of Object.entries(r.metafile.outputs)){
  if(meta.entryPoint){ const n=path.basename(meta.entryPoint).replace(/\.js$/,''); manifest[n==='live'?'live.js':n+'.js']='/'+path.relative(app,file).replace(/\\/g,'/'); }
}
// CSS: concatenate (fonts + page css), minify, hash
for (const [name,parts] of Object.entries(cssPrefix)){
  const src = parts.map(p=>fs.readFileSync(`${app}/static/src/${p}`,'utf8')).join('\n');
  const res = await (await import('esbuild')).transform(src,{loader:'css',minify:true});
  const h = (await import('node:crypto')).createHash('sha256').update(res.code).digest('hex').slice(0,8).toUpperCase();
  const f = `${name.replace('.css','')}-${h}.css`; fs.writeFileSync(path.join(out,f),res.code); manifest[name]='/static/dist/'+f;
}
fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify(manifest,null,2));
console.log(manifest);
for (const [f,m] of Object.entries(r.metafile.outputs)) console.log(String(m.bytes).padStart(8),path.relative(app,f));
