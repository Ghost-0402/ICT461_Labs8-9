import json, sys, glob, statistics
label = sys.argv[1]; runs = sorted(glob.glob(f"lh/{label}_run*.report.json"))
M = {"performance score": lambda j: round(j["categories"]["performance"]["score"]*100),
     "FCP (ms)": lambda j: j["audits"]["first-contentful-paint"]["numericValue"],
     "LCP (ms)": lambda j: j["audits"]["largest-contentful-paint"]["numericValue"],
     "TBT (ms)": lambda j: j["audits"]["total-blocking-time"]["numericValue"],
     "CLS": lambda j: j["audits"]["cumulative-layout-shift"]["numericValue"],
     "Speed Index (ms)": lambda j: j["audits"]["speed-index"]["numericValue"],
     "TTFB / server response (ms)": lambda j: j["audits"]["server-response-time"]["numericValue"],
     "total transfer (KB)": lambda j: j["audits"]["total-byte-weight"]["numericValue"]/1024,
     "HTML document (KB)": lambda j: next((i["transferSize"] for i in j["audits"]["network-requests"]["details"]["items"] if i["resourceType"]=="Document"),0)/1024,
     "requests": lambda j: len(j["audits"]["network-requests"]["details"]["items"])}
js = [json.load(open(r)) for r in runs]
print(f"{label}: {len(js)} runs (median shown)")
for k, f in M.items():
    vals = [f(j) for j in js]; print(f"  {k:30s} median={statistics.median(vals):>10.3f}   runs={[round(v,3) for v in vals]}")
j = js[len(js)//2]
try:
    it = j["audits"]["largest-contentful-paint-element"]["details"]["items"][0]["items"][0]["node"]; print("  LCP element:", it.get("snippet","")[:120])
except Exception: print("  LCP element: n/a")
for aid in ["render-blocking-resources","unused-javascript","unused-css-rules","uses-text-compression","uses-long-cache-ttl","uses-optimized-images","modern-image-formats","uses-responsive-images","unminified-javascript","unminified-css","largest-contentful-paint-element","long-tasks","dom-size","font-display","mainthread-work-breakdown","server-response-time","offscreen-images","uses-rel-preconnect","lcp-lazy-loaded","prioritize-lcp-image","document-latency-insight","render-blocking-insight","network-dependency-tree-insight","lcp-breakdown-insight","lcp-discovery-insight","legacy-javascript-insight","cache-insight","image-delivery-insight","font-display-insight","third-parties-insight","forced-reflow-insight","dom-size-insight","duplicated-javascript-insight"]:
    a = j["audits"].get(aid)
    if a and a.get("score") is not None and a["score"] < 0.9: print(f"  [opp] {aid}: score={a['score']} {a.get('displayValue','')}")
