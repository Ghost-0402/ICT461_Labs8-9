"""Lab 8 / Task 1 evidence: what the server answers to the HTTP Upgrade request, with and without credentials.
Raw sockets are used so the exact status line and headers are visible (this is what DevTools shows as 101 / 401)."""
import base64, os, socket, sys, tempfile, subprocess, time, json
APP = "/home/claude/lab89/app"; PORT_H, PORT_W = 5100, 5150
tmp = tempfile.mkdtemp()
env = {**os.environ, "DATABASE_PATH": tmp + "/h.db", "PORT": str(PORT_H), "WS_PORT": str(PORT_W), "WS_ALLOWED_ORIGINS": f"http://127.0.0.1:{PORT_H}"}
srv = subprocess.Popen([sys.executable, "app.py"], cwd=APP, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); time.sleep(3)
sys.path.insert(0, APP); os.environ.update({"DATABASE_PATH": tmp + "/h.db"}); os.chdir(APP)
import database, ownership
database.DB_PATH = tmp + "/h.db"
database.checkin_student("202302571", "Dennis Sampa", "BSc CS", "ground", "G7", None, None)
token = ownership.issue("202302571")
def upgrade(cookie=None, origin=None):
    key = base64.b64encode(os.urandom(16)).decode()
    req = f"GET /api/ws HTTP/1.1\r\nHost: 127.0.0.1:{PORT_W}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n"
    if origin: req += f"Origin: {origin}\r\n"
    if cookie: req += f"Cookie: {cookie}\r\n"
    s = socket.create_connection(("127.0.0.1", PORT_W)); s.sendall((req + "\r\n").encode()); time.sleep(0.4)
    data = s.recv(4096).decode(errors="replace"); s.close(); return req, data
out = []
for title, kw in [("1. No cookie (anonymous visitor)", dict(origin=f"http://127.0.0.1:{PORT_H}")),
                  ("2. Valid seat-token cookie, but request comes from another website (cross-site WebSocket hijacking attempt)", dict(cookie=f"seatToken={token}", origin="https://evil.example")),
                  ("3. Forged / unknown seat token", dict(cookie="seatToken=forged-token-value", origin=f"http://127.0.0.1:{PORT_H}")),
                  ("4. Valid seat-token cookie from the real site", dict(cookie=f"seatToken={token}", origin=f"http://127.0.0.1:{PORT_H}"))]:
    req, resp = upgrade(**kw)
    req_show = req.replace(token, "<seat-token>")
    out.append(f"##### {title}\n--- request ---\n{req_show.strip()}\n--- response ---\n{resp.split(chr(13)+chr(10)+chr(13)+chr(10))[0].strip()}\n")
srv.terminate()
open("handshake_log.txt", "w").write("\n".join(out)); print("\n".join(out))
