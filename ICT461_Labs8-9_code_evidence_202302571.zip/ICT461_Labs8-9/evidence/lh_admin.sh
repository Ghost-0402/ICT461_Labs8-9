#!/bin/bash
# usage: lh_admin.sh <label> <base-url> <runs>  -- audits the authenticated librarian dashboard by sending the signed admin session cookie
LABEL=$1; URL=$2; RUNS=${3:-3}; C=$(cat /tmp/w8/admin_cookie.txt)
for i in $(seq 1 $RUNS); do
  /home/claude/lab89/tools/node_modules/.bin/lighthouse "$URL/admin" --chrome-path=/usr/bin/google-chrome --chrome-flags="--headless=new --no-sandbox" \
    --only-categories=performance --extra-headers="{\"Cookie\":\"session=$C\"}" --output=json --output=html --output-path="/home/claude/lab89/evidence/lh/${LABEL}_run${i}" --quiet 2>&1 | tail -2
done
