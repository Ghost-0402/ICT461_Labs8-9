// Lab 9 probe: real-browser page loads with network + CPU throttling. usage: node perf_probe.js <app dir> <label>
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const { spawn } = require('child_process'); const fs = require('fs'), os = require('os'), path = require('path');
const APP = process.argv[2], LABEL = process.argv[3], OUT = __dirname + '/perf_probe_' + LABEL + '.txt';
const env0 = Object.fromEntries(fs.readFileSync(APP + '/.env', 'utf8').split('\n').filter(l => l.includes('=')).map(l => l.split(/=(.*)/s).slice(0, 2)));
const DB = path.join(os.tmpdir(), 'perf_' + LABEL + '.db'); try { fs.unlinkSync(DB); } catch (e) {}
const out = []; const log = s => { console.log(s); out.push(s); }; const sleep = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  const srv = spawn('python3', ['app.py'], { cwd: APP, env: { ...process.env, PORT: '5000', DATABASE_PATH: DB, WS_PORT: '5050', MU_IGNORE_HOURS: '1', APP_ENV: 'development', PYTHONUNBUFFERED: '1' } });
  await sleep(4500);
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 412, height: 823 }, deviceScaleFactor: 2.625, isMobile: true });
  await ctx.addInitScript(() => { window.__ev = []; new PerformanceObserver(l => l.getEntries().forEach(e => window.__ev.push({ n: e.name, d: e.duration, id: e.interactionId || 0 }))).observe({ type: 'event', durationThreshold: 16, buffered: true });
    window.__cls = 0; new PerformanceObserver(l => l.getEntries().forEach(e => { if (!e.hadRecentInput) window.__cls += e.value; })).observe({ type: 'layout-shift', buffered: true });
    window.__lcp = 0; new PerformanceObserver(l => l.getEntries().forEach(e => window.__lcp = e.startTime)).observe({ type: 'largest-contentful-paint', buffered: true }); });
  async function visit(name, url, interact, throttle = true) {
    const p = await ctx.newPage(); const cdp = await ctx.newCDPSession(p); await cdp.send('Network.enable'); await cdp.send('Network.setCacheDisabled', { cacheDisabled: false });
    if (throttle) { await cdp.send('Network.emulateNetworkConditions', { offline: false, latency: 150, downloadThroughput: 1.6 * 1024 * 1024 / 8, uploadThroughput: 750 * 1024 / 8 }); await cdp.send('Emulation.setCPUThrottlingRate', { rate: 4 }); }
    const reqs = {}, errs = [];
    cdp.on('Network.responseReceived', e => { reqs[e.requestId] = { url: e.response.url.replace('http://localhost:5000', ''), status: e.response.status, enc: (Object.entries(e.response.headers).find(([k]) => k.toLowerCase() === 'content-encoding') || [0, '-'])[1], cc: (Object.entries(e.response.headers).find(([k]) => k.toLowerCase() === 'cache-control') || [0, '-'])[1], type: e.type, fromCache: e.response.fromDiskCache || false, cached: (reqs[e.requestId] || {}).cached || e.response.fromDiskCache || false }; });
    cdp.on('Network.requestServedFromCache', e => { if (reqs[e.requestId]) reqs[e.requestId].cached = true; else reqs[e.requestId] = { cached: true, pending: true }; });
    cdp.on('Network.loadingFinished', e => { if (reqs[e.requestId]) reqs[e.requestId].bytes = e.encodedDataLength; });
    p.on('console', m => { if (m.type() === 'error') errs.push(m.text().slice(0, 160)); }); p.on('pageerror', e => errs.push('pageerror ' + e.message.slice(0, 160)));
    const t0 = Date.now(); await p.goto(url, { waitUntil: 'load' }); const tLoad = Date.now() - t0;
    if (interact) await interact(p); await sleep(1500);
    const m = await p.evaluate(() => ({ lcp: Math.round(window.__lcp), cls: +window.__cls.toFixed(4), ev: window.__ev, fonts: [...document.fonts].filter(f => f.status === 'loaded').map(f => f.family + ' ' + f.weight) }));
    const list = Object.values(reqs); const total = list.reduce((a, r) => a + (r.cached ? 0 : (r.bytes || 0)), 0);
    const inter = {}; m.ev.filter(e => e.id).forEach(e => inter[e.id] = Math.max(inter[e.id] || 0, e.d)); const ds = Object.values(inter).sort((a, b) => a - b);
    const inp = ds.length ? ds[Math.min(ds.length - 1, Math.floor(ds.length * 0.98))] : 0;
    log(`\n### ${LABEL} :: ${name}  (mobile 412x823, 1.6 Mbps/150 ms RTT, CPU 4x)`);
    log(`load event ${tLoad} ms | LCP ${m.lcp} ms | CLS ${m.cls} | INP(approx, ${ds.length} interactions) ${Math.round(inp)} ms | requests ${list.length} | transferred ${(total / 1024).toFixed(1)} KB | console errors ${errs.length}`);
    list.sort((a, b) => (b.bytes || 0) - (a.bytes || 0)).forEach(r => log(`  ${String(r.status).padEnd(4)} ${String(((r.bytes || 0) / 1024).toFixed(1)).padStart(7)} KB  ${r.cached ? 'CACHE' : r.enc.padEnd(5)} ${r.url.slice(0, 70).padEnd(70)} ${r.cc.slice(0, 48)}`));
    errs.forEach(e => log('  ERR ' + e)); log('  fonts loaded: ' + [...new Set(m.fonts)].join(', '));
    await p.close(); return { total, lcp: m.lcp, inp, n: list.length };
  }
  const tabs = async p => { await p.click('#inp-sid'); await p.keyboard.type('202300999', { delay: 80 }); await p.click('#inp-name'); await p.keyboard.type('Test Student', { delay: 80 }); await p.click('text=Continue to GPS Verification'); await sleep(400); for (let i = 0; i < 3; i++) { await p.click('#gps-btn', { timeout: 3000 }).catch(() => {}); await sleep(400); } };
  await visit('student page, cold cache', 'http://localhost:5000/', tabs);
  await visit('student page, repeat visit (warm cache)', 'http://localhost:5000/', null);
  const ap = await ctx.newPage(); await ap.goto('http://localhost:5000/admin'); await ap.fill('#pin', env0.MU_ADMIN_PIN); await ap.click('#go'); await sleep(1500); await ap.close();
  await visit('admin dashboard, warm shell', 'http://localhost:5000/admin', async p => { await p.waitForSelector('canvas', { timeout: 15000 }); });
  await b.close(); srv.kill('SIGKILL'); fs.writeFileSync(OUT, out.join('\n') + '\n');
})().catch(e => { console.error(e); process.exit(1); });
