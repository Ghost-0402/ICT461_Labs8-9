#!/bin/bash
# usage: lh.sh <label> <url> <runs>   (Lighthouse mobile emulation: Moto G Power, simulated Slow 4G, 4x CPU slowdown = Lighthouse defaults)
LABEL=$1; URL=$2; RUNS=${3:-3}
for i in $(seq 1 $RUNS); do
  /home/claude/lab89/tools/node_modules/.bin/lighthouse "$URL" --chrome-path=/usr/bin/google-chrome \
    --chrome-flags="--headless=new --no-sandbox --ignore-certificate-errors" --only-categories=performance \
    --output=json --output=html --output-path="/home/claude/lab89/evidence/lh/${LABEL}_run${i}" --quiet 2>&1 | tail -2
done
