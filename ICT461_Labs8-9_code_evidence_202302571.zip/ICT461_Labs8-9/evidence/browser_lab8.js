// Lab 8 browser evidence: two students + librarian over wss://, live delivery, private events, offline replay, server restart backoff.
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const { spawn, execSync } = require('child_process'); const fs = require('fs'), os = require('os'), path = require('path');
const APP = '/home/claude/lab89/app', OUT = __dirname + '/';
const env0 = Object.fromEntries(fs.readFileSync(APP + '/.env', 'utf8').split('\n').filter(l => l.includes('=')).map(l => l.split(/=(.*)/s).slice(0, 2)));
const DB = path.join(os.tmpdir(), 'lab8_browser.db'); try { fs.unlinkSync(DB); } catch (e) {}
const lines = []; const log = (s) => { console.log(s); lines.push(s); };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const serverLog = fs.createWriteStream(OUT + 'ws_server_log.txt');
function startServer() {
  const p = spawn('python3', ['serve_https.py'], { cwd: APP, env: { ...process.env, DATABASE_PATH: DB, WS_PORT: '5051', WS_PUBLIC_PORT: '5050', WS_HEARTBEAT_INTERVAL: '10', WS_HEARTBEAT_TIMEOUT: '5', PYTHONUNBUFFERED: '1', MU_IGNORE_HOURS: '1', APP_ENV: 'development' } });
  p.stdout.pipe(serverLog, { end: false }); p.stderr.on('data', d => { const t = d.toString(); if (/mu\.ws|CONNECT|EVICT|PING|PONG|SYNC/.test(t)) serverLog.write(t); });
  return p;
}
const net = require('net'); const proxy = { blocked: false, socks: new Set() };
proxy.server = net.createServer(c => { if (proxy.blocked) return c.destroy(); const u = net.connect(5051, '127.0.0.1'); proxy.socks.add(c); proxy.socks.add(u);
  c.pipe(u); u.pipe(c); const done = () => { c.destroy(); u.destroy(); proxy.socks.delete(c); proxy.socks.delete(u); }; c.on('error', done); u.on('error', done); c.on('close', done); u.on('close', done); });
proxy.outage = on => { proxy.blocked = on; if (on) for (const x of proxy.socks) x.destroy(); };
proxy.server.listen(5050, '127.0.0.1');
const ts = () => new Date().toISOString().slice(11, 23);
(async () => {
  let server = global.srv = startServer(); await sleep(4000);
  const b = await chromium.launch();
  const geo = { geolocation: { latitude: -14.2962, longitude: 28.5605 }, permissions: ['geolocation'] };
  const mk = async (w = 1100, h = 900) => { const ctx = await b.newContext({ ignoreHTTPSErrors: true, viewport: { width: w, height: h }, ...geo }); const p = await ctx.newPage(); return { ctx, p }; };
  const feedText = p => p.evaluate(() => document.getElementById('live-feed').innerText.replace(/\s+/g, ' '));
  const badge = p => p.evaluate(() => document.getElementById('ws-badge').textContent);
  async function checkin(p, sid, name, seat, floorTab) {
    await p.goto('https://localhost:8443/'); await p.waitForTimeout(500);
    await p.fill('#inp-sid', sid); await p.fill('#inp-name', name); await p.fill('#inp-course', 'BSc Computer Science');
    await p.click('text=Continue to GPS Verification'); await p.click('#gps-btn'); await p.waitForFunction(() => !document.getElementById('gps-next').disabled, null, { timeout: 8000 });
    await p.click('#gps-next'); if (floorTab) await p.click('.floor-tab:has-text("' + floorTab + '")'); await p.fill('#inp-seat', seat); await p.click('.seat-confirm-btn');
    const r = p.waitForResponse(x => x.url().endsWith('/api/checkin')); await p.click('#checkin-btn'); await r; return Date.now();
  }
  // ---- 0. anonymous visitor: the page opens a socket without credentials -> rejected, never opens
  { const { ctx, p } = await mk(); await p.goto('https://localhost:8443/'); 
    const res = await p.evaluate(() => new Promise(res => { const w = new WebSocket('wss://localhost:5050/api/ws'); let opened = false; w.onopen = () => { opened = true; }; w.onclose = e => res({ opened, code: e.code }); }));
    log(`[${ts()}] ANON socket from the browser (no cookie): opened=${res.opened} closeCode=${res.code}  (handshake answered 401, see handshake_log.txt)`); await ctx.close(); }
  // ---- 1. librarian
  const A = await mk(1100, 1000); await A.p.goto('https://localhost:8443/admin'); await A.p.fill('#pin', env0.MU_ADMIN_PIN); await A.p.click('#go'); await A.p.waitForTimeout(1200);
  await A.p.goto('https://localhost:8443/admin'); await A.p.waitForFunction(() => document.getElementById('ws-badge').dataset.state === 'connected', null, { timeout: 8000 });
  log(`[${ts()}] ADMIN badge: ${await badge(A.p)}`);
  // ---- 2. student 1 (ground) with CDP trace of the WebSocket
  const S1 = await mk(1100, 1100); const cdp = await S1.ctx.newCDPSession(S1.p); await cdp.send('Network.enable'); const trace = [];
  cdp.on('Network.webSocketCreated', e => trace.push(`webSocketCreated  url=${e.url}`));
  cdp.on('Network.webSocketWillSendHandshakeRequest', e => { const h = e.request.headers; trace.push('Handshake REQUEST headers:\n' + Object.entries(h).map(([k, v]) => `   ${k}: ${/cookie/i.test(k) ? v.replace(/seatToken=[^;]+/, 'seatToken=<hidden>') : v}`).join('\n')); });
  cdp.on('Network.webSocketHandshakeRequestExtraInfo', e => trace.push('Handshake REQUEST, headers added by the browser network stack (HttpOnly cookie sent automatically):\n' + Object.entries(e.headers).filter(([k]) => /cookie|origin|host/i.test(k)).map(([k, v]) => `   ${k}: ${v.replace(/seatToken=[^;]+/, 'seatToken=<hidden>')}`).join('\n')));
  cdp.on('Network.webSocketHandshakeResponseReceived', e => trace.push(`Handshake RESPONSE: HTTP ${e.response.status} ${e.response.statusText}\n` + Object.entries(e.response.headers).map(([k, v]) => `   ${k}: ${v}`).join('\n')));
  cdp.on('Network.webSocketFrameReceived', e => trace.push(`frame RECEIVED (opcode ${e.response.opcode}): ${e.response.payloadData.slice(0, 160)}`));
  cdp.on('Network.webSocketFrameSent', e => trace.push(`frame SENT     (opcode ${e.response.opcode}): ${e.response.payloadData.slice(0, 160)}`));
  const t1 = await checkin(S1.p, '202300101', 'Peter Oneil', 'G22');
  await A.p.waitForFunction(() => document.getElementById('live-feed').innerText.includes('Peter Oneil'), null, { timeout: 5000 }); const d1 = Date.now() - t1;
  log(`[${ts()}] CHECK-IN student1 (ground G22): librarian dashboard feed updated ${d1} ms after the HTTP check-in response, no reload`);
  await S1.p.waitForFunction(() => document.getElementById('ws-badge').dataset.state === 'connected'); log(`[${ts()}] STUDENT1 badge: ${await badge(S1.p)}`);
  // ---- 3. student 2 (first floor)
  const S2 = await mk(1100, 1100); const t2 = await checkin(S2.p, '202300102', 'Mary Banda', 'F5', '1st');
  await A.p.waitForFunction(() => document.getElementById('live-feed').innerText.includes('Mary Banda'), null, { timeout: 5000 }); log(`[${ts()}] CHECK-IN student2 (first floor F5): dashboard updated ${Date.now() - t2} ms later`);
  await S1.p.waitForFunction(() => /2 students? inside/.test(document.getElementById('active-count-lbl').textContent), null, { timeout: 5000 });
  log(`[${ts()}] STUDENT1 sees "${await S1.p.textContent('#active-count-lbl')}" without reloading (occupancy event in room "all")`);
  await A.p.screenshot({ path: OUT + 'w1_admin_live.png' }); await S1.p.screenshot({ path: OUT + 'w2_student_live.png' });
  // ---- 4. student -> librarian report (bi-directional)
  await S2.p.fill('#live-report-text', 'Broken lamp at F5'); await S2.p.click('text=Send');
  await A.p.waitForFunction(() => document.getElementById('live-feed').innerText.includes('Broken lamp at F5'), null, { timeout: 5000 });
  log(`[${ts()}] REPORT from student2 delivered live to the librarian feed: "${(await feedText(A.p)).slice(0, 120)}"`);
  // ---- 5. librarian announcement reaches every student
  await A.p.fill('#live-announce-text', 'Library closes at 18:00 today'); await A.p.click('text=Broadcast');
  for (const [n, s] of [['student1', S1], ['student2', S2]]) { await s.p.waitForFunction(() => document.getElementById('live-feed').innerText.includes('closes at 18:00'), null, { timeout: 5000 }); log(`[${ts()}] ANNOUNCEMENT received by ${n}: ${(await feedText(s.p)).slice(0, 100)}`); }
  // ---- 6. student 2 loses the network, events happen, network returns -> replay
  proxy.outage(true); await sleep(2500);   // network outage for everyone: every socket is reset and new connections are refused
  log(`[${ts()}] NETWORK OUTAGE (all sockets reset). badges: student1=${await badge(S1.p)} | student2=${await badge(S2.p)} | librarian=${await badge(A.p)}`);
  await S2.p.screenshot({ path: OUT + 'w3_student2_offline.png' });
  const ann = await A.p.evaluate(async () => (await fetch('/api/admin/announce', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text: 'Exam timetable posted on Moodle' }) })).json());
  log(`[${ts()}] librarian posts an announcement over plain HTTP while the live channel is down -> ${JSON.stringify(ann)}`);
  execSync(`python3 - <<'PY'
import os, sys, sqlite3
os.environ.update({"MU_IGNORE_HOURS": "1", "DATABASE_PATH": "${DB}", "MU_SECRET_KEY": "x"*40, "MU_ADMIN_PIN": "Some-Pin-123", "APP_ENV": "development"}); os.chdir("${APP}"); sys.path.insert(0, ".")
import database, realtime
database.DB_PATH = "${DB}"; database.warn = realtime.warn_once
c = sqlite3.connect("${DB}"); from datetime import datetime, timedelta
c.execute("UPDATE active_sessions SET status='away', away_since=? WHERE student_id='202300102'", ((datetime.now() - timedelta(minutes=16)).isoformat(),)); c.commit(); c.close()
database.cleanup_expired_sessions()
PY`);
  await sleep(500); log(`[${ts()}] While student2 was offline: 1 announcement + 1 private away warning were stored in the events table`);
  proxy.outage(false); await S2.p.waitForFunction(() => document.getElementById('ws-badge').dataset.state === 'connected', null, { timeout: 40000 }); await S2.p.waitForTimeout(800);
  const f2 = await feedText(S2.p); log(`[${ts()}] NETWORK RESTORED. STUDENT2 badge: ${await badge(S2.p)}; feed: ${f2.slice(0, 260)}`); await S2.p.screenshot({ path: OUT + 'w4_student2_caught_up.png' });
  // ---- 7. rooms: librarian force-checks-out student 1: only student 1 gets the private message
  await A.p.waitForTimeout(300);
  await A.p.evaluate(async () => { await fetch('/api/admin/force_checkout', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ student_id: '202300101' }) }); });
  await S1.p.waitForFunction(() => document.getElementById('main-card').style.display !== 'none', null, { timeout: 5000 });
  log(`[${ts()}] FORCE CHECK-OUT of student1: student1 UI returned to the login screen immediately (private event "session_ended" in room user:202300101)`);
  log(`[${ts()}] student2 feed does NOT contain student1's private message: ${!(await feedText(S2.p)).includes('librarian released your seat')}`);
  log(`[${ts()}] ADMIN ws_stats: ${JSON.stringify(await A.p.evaluate(async () => (await fetch('/api/admin/ws_stats')).json()))}`);
  fs.writeFileSync(OUT + 'ws_cdp_trace.txt', trace.join('\n') + '\n');
  // ---- 8. server restart: exponential backoff with jitter
  const S3 = await mk(1100, 1100); const con = []; S3.p.on('console', m => { if (m.text().startsWith('[live')) con.push(m.text()); });
  await checkin(S3.p, '202300103', 'Carol Mwale', 'G30'); await S3.p.waitForFunction(() => document.getElementById('ws-badge').dataset.state === 'connected'); await S3.p.waitForTimeout(500);
  log(`[${ts()}] === SERVER RESTART TEST === killing the server process now`); const tKill = Date.now();
  server.kill('SIGKILL'); await sleep(22000); log(`[${ts()}] STUDENT3 badge during outage: ${await badge(S3.p)}`); await S3.p.screenshot({ path: OUT + 'w5_reconnecting.png' });
  log(`[${ts()}] starting the server again (outage ${(Date.now() - tKill) / 1000}s)`); server = global.srv = startServer();
  await S3.p.waitForFunction(() => document.getElementById('ws-badge').dataset.state === 'connected', null, { timeout: 45000 }); const tBack = Date.now();
  log(`[${ts()}] STUDENT3 reconnected ${((tBack - tKill) / 1000).toFixed(1)} s after the kill; badge: ${await badge(S3.p)}`); await S3.p.waitForTimeout(500); await S3.p.screenshot({ path: OUT + 'w6_reconnected.png' });
  fs.writeFileSync(OUT + 'client_backoff_console.txt', con.join('\n') + '\n'); log('--- student3 browser console ---\n' + con.join('\n'));
  fs.writeFileSync(OUT + 'browser_lab8.txt', lines.join('\n') + '\n');
  proxy.server.close(); await b.close(); server.kill('SIGKILL'); process.exit(0);
})().catch(e => { console.error('FAILED', e); fs.writeFileSync(OUT + 'browser_lab8.txt', lines.join('\n') + '\nFAILED ' + e + '\n'); global.srv && global.srv.kill('SIGKILL'); process.exit(1); });
