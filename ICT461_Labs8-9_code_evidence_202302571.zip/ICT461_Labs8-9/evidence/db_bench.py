"""Lab 9: dashboard query cost with 100,000 history rows, before (baseline code, no indexes) vs after (indexes + sargable predicates + cache)."""
import os, sys, random, sqlite3, time, importlib, statistics, tempfile
from datetime import datetime, timedelta
def load(appdir, db):
    os.environ["DATABASE_PATH"] = db
    sys.path.insert(0, appdir)
    for m in [m for m in sys.modules if m in ("database","config")]: del sys.modules[m]
    import database; database.DB_PATH = db; return database
def seed(db, n=100000):
    d = load("/home/claude/lab89/app_baseline", db); d.init_db()
    conn = sqlite3.connect(db); random.seed(1); now = datetime.now(); rows = []
    for i in range(n):
        ci = now - timedelta(days=random.random()*120, minutes=random.randint(0, 600)); dur = random.randint(600, 14400)
        rows.append((f"2023{i%9000:05d}", "Student %d" % (i%9000), "BSc CS", random.choice(["ground","first","second"]), "S%d" % random.randint(1,60),
                     ci.isoformat(), (ci+timedelta(seconds=dur)).isoformat(), dur, random.choice(["manual","auto_away","auto_max"]), None, None))
    conn.executemany("INSERT INTO session_history (student_id,full_name,course,floor,seat_number,check_in_time,check_out_time,duration_seconds,checkout_reason,latitude,longitude) VALUES (?,?,?,?,?,?,?,?,?,?,?)", rows)
    conn.commit(); conn.close(); sys.path.remove("/home/claude/lab89/app_baseline")
def bench(label, appdir, db):
    d = load(appdir, db); d.init_db()
    def t(fn, n=15):
        xs = []
        for _ in range(n):
            if hasattr(d, "invalidate_aggregates"): d.invalidate_aggregates()   # worst case: cold cache every call
            a = time.perf_counter(); fn(); xs.append((time.perf_counter()-a)*1000)
        return statistics.median(xs)
    r = {"get_stats (cold)": t(d.get_stats), "get_chart_data (cold)": t(d.get_chart_data), "history page (50 rows)": t(lambda: d.get_session_history(50) if "after" in label else d.get_session_history(200))}
    if hasattr(d, "invalidate_aggregates"):
        d.get_stats(); a = time.perf_counter(); [d.get_stats() for _ in range(1000)]; r["get_stats (cache hit)"] = (time.perf_counter()-a)  # 1000 calls, seconds == ms per call  # ms per call = total_s
    sys.path.remove(appdir); return r
import shutil
db = os.path.join(tempfile.gettempdir(), "bench100k.db")
for f in (db, db+".b", db+".a"):
    if os.path.exists(f): os.remove(f)
seed(db); shutil.copy(db, db+".b"); shutil.copy(db, db+".a")
conn = sqlite3.connect(db); print("rows:", conn.execute("select count(*) from session_history").fetchone()[0], "| db size MB:", round(os.path.getsize(db)/1e6,1))
conn.close()
b = bench("before", "/home/claude/lab89/app_baseline", db+".b"); a = bench("after", "/home/claude/lab89/app", db+".a")
print(f"{'query':28}{'before (ms)':>14}{'after (ms)':>14}")
for k in b: print(f"{k:28}{b[k]:>14.2f}{a[k]:>14.2f}")
print("get_stats (cache hit)        ", "n/a", f"{a['get_stats (cache hit)']:.4f} ms per call (1000 calls)")
