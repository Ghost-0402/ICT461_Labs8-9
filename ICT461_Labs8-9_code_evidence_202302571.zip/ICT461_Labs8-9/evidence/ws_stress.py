"""Lab 8 / Task 3 + DevOps role: heartbeat eviction and concurrency stress test of the WebSocket engine.
Server runs with a short heartbeat (interval 3 s, timeout 2 s) so evictions happen quickly; production default is 25 s / 10 s."""
import asyncio, base64, json, os, statistics, subprocess, sys, tempfile, time, urllib.request
sys.path.insert(0, "/home/claude/lab89/app")
APP = "/home/claude/lab89/app"; TMP = tempfile.mkdtemp(); DB = TMP + "/stress.db"; SECRET = "stress-test-secret-key-0123456789abcdefghij"
HP, WP = 5200, 5250; ORIGIN = f"http://127.0.0.1:{HP}"; LOGF = os.path.abspath("ws_heartbeat_log.txt")
open(LOGF, "w").close()
env = {**os.environ, "DATABASE_PATH": DB, "PORT": str(HP), "WS_PORT": str(WP), "WS_ALLOWED_ORIGINS": ORIGIN, "WS_HEARTBEAT_INTERVAL": "3",
       "WS_HEARTBEAT_TIMEOUT": "2", "MU_SECRET_KEY": SECRET, "MU_ADMIN_PIN": "Stress-Pin-1234", "APP_ENV": "development", "MU_IGNORE_HOURS": "1", "WS_LOG_FILE": LOGF}
os.environ.update(env); os.chdir(APP)
import database, ownership
database.DB_PATH = DB; database.init_db(); ownership.init_ownership()
tokens = {}
for i in range(120):
    floor, n = ["ground", "first", "second"][i // 40], i % 40 + 1
    sid = f"2025{i:05d}"; database.checkin_student(sid, f"Student {i}", "BSc", floor, f"{'GFS'[i//40]}{n}", None, None); tokens[sid] = ownership.issue(sid)
from flask import Flask; from flask.sessions import SecureCookieSessionInterface
_a = Flask("x"); _a.secret_key = SECRET
ADMIN = "session=" + SecureCookieSessionInterface().get_signing_serializer(_a).dumps({"admin_logged_in": True})
srv = subprocess.Popen([sys.executable, "app.py"], cwd=APP, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); time.sleep(3.5)
import websockets
URL = f"ws://127.0.0.1:{WP}/api/ws"; out = []
def say(s=""): print(s, flush=True); out.append(s)
def rss_mb(): return int([l for l in open(f"/proc/{srv.pid}/status") if l.startswith("VmRSS")][0].split()[1]) / 1024
def fds(): return len(os.listdir(f"/proc/{srv.pid}/fd"))
def stats():
    r = urllib.request.Request(f"http://127.0.0.1:{HP}/api/admin/ws_stats", headers={"Cookie": ADMIN}); return json.load(urllib.request.urlopen(r))
def snap(label):
    s = stats(); say(f"  [{label}] server connections={s['connected']} (students={s['students']}, admins={s['admins']}) evicted_total={s['evicted']} pings={s['pings']} pongs={s['pongs']}  RSS={rss_mb():.1f} MB  open fds={fds()}")
async def conn(cookie): return await websockets.connect(URL, additional_headers={"Cookie": cookie, "Origin": ORIGIN}, compression=None, max_size=None)
async def main():
    say("Lab 8 WebSocket stress and heartbeat test (heartbeat interval 3 s, timeout 2 s)"); say(f"server pid {srv.pid}")
    snap("idle, before any client")
    # A. 120 concurrent authenticated students + 1 librarian
    t0 = time.monotonic(); lat = []
    async def one(sid):
        t = time.monotonic(); ws = await conn("seatToken=" + tokens[sid]); h = json.loads(await ws.recv()); lat.append((time.monotonic() - t) * 1000); assert h["type"] == "hello"; return ws
    clients = await asyncio.gather(*(one(s) for s in tokens)); admin = await conn(ADMIN); await admin.recv()
    say(f"A. {len(clients)} students + 1 librarian connected concurrently in {time.monotonic()-t0:.2f}s; handshake+hello latency ms: p50={statistics.median(lat):.1f} p95={sorted(lat)[int(len(lat)*.95)]:.1f} max={max(lat):.1f}")
    snap("120 clients connected")
    # B. fan-out of one persisted announcement to 120 clients
    recv = {}
    async def listen(i, ws):
        try:
            async for m in ws:
                f = json.loads(m)
                if f.get("kind") == "announcement" and i >= 0: recv.setdefault(i, []).append(time.monotonic())
        except Exception: pass
    tasks = [asyncio.create_task(listen(i, w)) for i, w in enumerate(clients)] + [asyncio.create_task(listen(-1, admin))]   # every client keeps reading, like a real browser
    t = time.monotonic(); await admin.send(json.dumps({"type": "announce", "text": "Fan-out test one"})); await asyncio.sleep(1.0)
    done = [v[0] - t for v in recv.values()]
    say(f"B. one announcement from the librarian reached {len(done)}/{len(clients)} students; delivery time ms: p50={statistics.median(done)*1000:.1f} max={max(done)*1000:.1f}")
    # C. burst: 100 announcements over HTTP -> 12,000 deliveries
    recv.clear(); t = time.monotonic()
    def post(i):
        r = urllib.request.Request(f"http://127.0.0.1:{HP}/api/admin/announce", data=json.dumps({"text": f"Burst {i}"}).encode(), headers={"Cookie": ADMIN, "Content-Type": "application/json"}); return urllib.request.urlopen(r).status
    await asyncio.get_event_loop().run_in_executor(None, lambda: [post(i) for i in range(100)])
    t_posted = time.monotonic() - t; await asyncio.sleep(2.0)
    total = sum(len(v) for v in recv.values())
    say(f"C. burst of 100 persisted announcements (posted in {t_posted:.2f}s) -> {total} deliveries to {len(recv)} clients (expected {100*len(clients)}); all received={total == 100*len(clients)}")
    # D. heartbeat: 10 half-open clients (complete the handshake, then never answer a Ping)
    snap("before half-open clients")
    half = []
    for sid in list(tokens)[:10]:
        r, w = await asyncio.open_connection("127.0.0.1", WP); key = base64.b64encode(os.urandom(16)).decode()
        w.write((f"GET /api/ws HTTP/1.1\r\nHost: 127.0.0.1:{WP}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\nOrigin: {ORIGIN}\r\nCookie: seatToken={tokens[sid]}\r\n\r\n").encode())
        await w.drain(); await r.readuntil(b"\r\n\r\n"); half.append((r, w))
    snap("+10 half-open clients (never reply to Ping)")
    t = time.monotonic(); ev0 = stats()["evicted"]
    while stats()["evicted"] - ev0 < 10 and time.monotonic() - t < 15: await asyncio.sleep(0.25)
    say(f"D. all {stats()['evicted'] - ev0} half-open connections evicted {time.monotonic()-t:.1f}s after connecting (interval 3 s + timeout 2 s)")
    snap("after eviction"); alive = sum(1 for w in clients if w.state.name == "OPEN"); say(f"   the 120 healthy clients are still connected: {alive}/120 (they answered every Ping automatically)")
    for r, w in half: w.close()
    # E. churn: 300 connect/disconnect cycles, check for leaks
    snap("before churn"); t = time.monotonic()
    async def cycle(i):
        sid = list(tokens)[i % 120]; ws = await conn("seatToken=" + tokens[sid]); await ws.recv(); await ws.close()
    for b in range(0, 300, 20): await asyncio.gather(*(cycle(i) for i in range(b, b + 20)))
    await asyncio.sleep(0.5); say(f"E. 300 connect/close cycles in {time.monotonic()-t:.1f}s"); snap("after churn")
    for t_ in tasks: t_.cancel()
    for w in clients + [admin]: await w.close()
    await asyncio.sleep(0.7); snap("all clients closed")
asyncio.run(main()); srv.terminate()
say("\n--- server heartbeat log (excerpt: first Ping/Pong lines and the evictions) ---")
L = open(LOGF).read().splitlines()
say("\n".join([l for l in L if "PING" in l or "PONG" in l][:6] + ["   ..."] + [l for l in L if "EVICT" in l][:10]))
say(f"counts in log: PING={sum('PING' in l for l in L)} PONG={sum('PONG' in l for l in L)} EVICT={sum('EVICT' in l for l in L)} REJECTED={sum('REJECTED' in l for l in L)}")
open("ws_stress_log.txt", "w").write("\n".join(out) + "\n")
