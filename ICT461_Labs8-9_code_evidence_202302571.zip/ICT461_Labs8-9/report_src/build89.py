import sys
exec(open("/home/claude/lab67/report/common.py").read())
A = "/home/claude/lab89/app/"; E = "/home/claude/lab89/evidence/"
LEAD = sys.argv[1] if len(sys.argv) > 1 else "To be confirmed (rotating team lead for Labs 8 and 9)"
def log(name, a=None, b=None, maxl=None):
    s = open(E + name, encoding="utf-8").read().rstrip("\n")
    if a: s = s[s.index(a):]
    if b: s = s[:s.index(b)]
    L = s.rstrip().split("\n")
    if maxl and len(L) > maxl: L = L[:maxl] + ["   ..."]
    return "\n".join(x[:128] for x in L)
def lines(path, a, b): return "\n".join(x[:118] for x in between(path, a, b).split("\n"))

# ---------------- cover ----------------
P("MULUNGUSHI UNIVERSITY", bold=True, align="c", size=18, after=0)
P("School of Engineering and Technology", align="c", size=12, after=0)
P("Department of Computer Science and Information Technology", align="c", size=12, after=14)
P("ICT461 ADVANCED WEB TECHNOLOGIES", bold=True, align="c", size=15, after=2)
P("Labs 8 and 9: Authenticated Real-Time Communication with WebSockets, and Web Performance Optimisation (Core Web Vitals, Assets, Caching and Compression)", bold=True, align="c", size=13, after=14)
TAB([["Project", "MU Library Seat Management System"], ["Group", "Group O"], ["Team lead (Labs 8 and 9)", LEAD],
     ["Student", "Dennis Sampa, 202302571"], ["Lecturer", "Mr. Kabaso B. Winston"], ["Submission deadline", "Friday 20 November 2026, 23:59 (Moodle)"],
     ["Date of report", "19 November 2026"]], widths=[5.5, 10.3], header=False, size=11)
P("Individual report. The code, test scripts and raw evidence are in the accompanying archive ICT461_Labs8-9_code_evidence_202302571.zip.", italic=True, align="c", size=10)
doc.add_page_break()

# ---------------- 1 introduction ----------------
H1("1. Introduction")
P("Labs 1 to 7 produced a secured Flask application with a student seat portal, a librarian dashboard, TLS 1.3 and a hardened data layer. Until now the pages learned about changes only by asking the server again and again (polling). Lab 8 replaces most of that polling with an authenticated WebSocket channel, so that a check-in on one phone appears on the librarian screen within milliseconds. Lab 9 then asks a different question: now that the application works and is safe, is it fast, and does it stay fast on a poor mobile network? Both labs were done on the same code base, so every Lab 9 measurement was taken on the application that already contains the Lab 8 channel.")
H2("1.1 Technology choices")
TAB([["Question", "Choice", "Reason"],
 ["Real-time transport", "WebSocket (RFC 6455), Python websockets 17.4", "Both sides must send at any time (student reports a broken lamp, librarian announces closing). Server-Sent Events are one-way and polling wastes requests. WebRTC (W3C) is designed for browser-to-browser media and needs signalling plus STUN/TURN servers; a library does not need peer-to-peer, so it was not used."],
 ["Where the WebSocket server runs", "A second listener (port 5050, daemon thread) beside Flask", "Flask's development server cannot hold open sockets efficiently. The two share the same code (database, ownership, session signing key) so the rules are written once."],
 ["Authentication", "Existing credentials, checked during the HTTP Upgrade", "No new password system. Student: HttpOnly seat-token cookie. Librarian: signed Flask session cookie. A refused client never gets a socket."],
 ["Front-end build", "esbuild 0.28", "One tool that minifies, tree-shakes, splits and hashes in milliseconds, with no config framework."],
 ["Measurement", "Lighthouse 13 (mobile, simulated Slow 4G, 4x CPU), Playwright probe, curl, SQLite benchmark", "Three independent tools so that no single number is trusted alone."]], widths=[3.2, 4.8, 7.8], size=9.5)
H2("1.2 Architecture after Labs 8 and 9")
TAB([["Layer", "Technology", "Role"],
 ["Browser", "HTML, esbuild bundles (ES modules), live.js ResilientSocket", "Pages, status badge, live feed, reconnection logic"],
 ["Web tier", "Flask + perf.py middleware", "Pages and REST API; cache policy, ETag/304, Brotli/gzip"],
 ["Real-time tier", "websockets server, rooms all / admin / floor:x / user:id", "Authenticated push, heartbeat, rate limit, schema validation"],
 ["Data tier", "SQLite pilot database (events table, indexed history)", "Persisted events for replay; dashboard aggregates"],
 ["Verification", "unittest (17 WebSocket + 19 security tests), Lighthouse, curl, Playwright", "Evidence for every claim below"]], widths=[3.0, 6.2, 6.6], size=9.5)
H2("1.3 Role matrix")
TAB([["Role", "Members", "Lab 8 focus", "Lab 9 focus"],
 ["Frontend and UX", "Lloyd Bulaya (202306274); Joy Silishebo (202302837)", "Connection status badge, live feed, reconnect messages (textContent only)", "Responsive WebP/AVIF images, font loading, Core Web Vitals checks"],
 ["Backend and API", "Cleopatra Ngoma (202301392); Annette Sianongo (202302878)", "Handshake authentication, message schemas, rooms", "Cache-Control, ETag and compression middleware"],
 ["Database and Auth", "Dennis Sampa (202302571); Gift Saya (202302133)", "Session checks at the handshake, event persistence and replay", "Indexes, pagination, aggregate cache, query benchmark"],
 ["DevOps and Real-Time", "Mushilo Mwewa Mayuya (202302315); Dada Mshisha (202200670)", "Heartbeat, eviction, load and leak tests", "esbuild pipeline, reverse-proxy/CDN configuration, Lighthouse runs"]], widths=[2.6, 4.2, 4.5, 4.5], size=9)
P("My own role is Database and Auth. In Lab 8 I worked on authentication at the handshake, the ownership token lookup, the events table and the replay query. In Lab 9 I worked on the indexes, the pagination and the aggregate cache. The other parts of the code were built by the group; I tested and ran all of it so that I can explain it.")

# ---------------- Part A ----------------
H1("2. Part A (Lab 8): Authenticated WebSocket engine and resilient client")
H2("2.1 The handshake is the authentication step")
P("A WebSocket starts as an ordinary HTTP request with Upgrade: websocket. The browser sends the user's cookies with it automatically, so the server can decide before the connection exists. The function process_request runs at that moment. If the request is refused, the answer is a normal HTTP status (401, 403, 404 or 429) and no socket is ever created.")
LISTING_TITLE("Listing 1: authenticate and process_request (app/ws_server.py)")
CODE(lines(A + "ws_server.py", "def authenticate(request):", "def rooms_for"))
CODE(lines(A + "ws_server.py", "async def process_request", "async def heartbeat"))
P("Three checks are made in order. (1) The Origin header must be on an allow-list; this stops Cross-Site WebSocket Hijacking, where a malicious page tries to use the visitor's cookies. (2) The librarian cookie must carry a valid signature from the Flask secret key and an admin flag. (3) A student must present the HttpOnly seat token issued at check-in, which is looked up by its SHA-256 hash. The raw handshake below was captured with a script that speaks plain HTTP to the server.")
LISTING_TITLE("Listing 2: raw handshake outcomes (evidence/handshake_log.txt, abbreviated)")
CODE("\n".join(l for l in open(E + "handshake_log.txt").read().split("\n") if l.startswith(("#####", "HTTP/1.1", "Origin", "Cookie", "Sec-WebSocket-Accept", "Upgrade:"))))
TAB([["Case", "Result", "Meaning"],
 ["No cookie", "HTTP 401", "Anonymous visitors cannot connect"],
 ["Valid cookie, Origin: https://evil.example", "HTTP 403", "Cross-site hijacking blocked"],
 ["Forged seat token", "HTTP 401", "Token is unknown to the database"],
 ["Valid cookie, real Origin", "HTTP 101 Switching Protocols + Sec-WebSocket-Accept", "Connection upgraded"],
 ["Fourth connection by one user", "HTTP 429", "Limit of 3 sockets per user (unit test)"]], widths=[5.6, 5.0, 5.2], size=9.5)
P("The same 101 response was observed from inside Chrome through the DevTools protocol (evidence/ws_cdp_trace.txt):")
CODE(log("ws_cdp_trace.txt", None, None, 17))

H2("2.2 Rooms and message format")
P("After the upgrade the server puts the connection in rooms: all (everyone), floor:<name> (students on that floor), user:<id> (private messages to one student) and admin (librarian only). Every server message is JSON with a type, a room, a kind and a data object. Events that must not be lost (announcements, warnings, check-ins) get an increasing id and are stored in an events table. Presence events such as the live occupancy counter are sent but not stored.")
H2("2.3 Input validation on every incoming frame")
P("A WebSocket frame is user input, exactly like a form field. Each frame is parsed as JSON and checked against a JSON Schema (Draft 2020-12) with three allowed shapes: sync, report and announce. Extra fields are rejected (additionalProperties false), text is limited to 200 characters and to a safe character set, and the error message never repeats the rejected value. Other protections: 4 KB maximum frame (close code 1009), binary frames refused (1003), 10 frames per 10 seconds, and three violations close the socket with code 1008. A student cannot send an announce frame even if the shape is valid, because the role is taken from the session, never from the message.")
LISTING_TITLE("Listing 3: frame schema (app/ws_schemas.py)")
CODE(grab(A + "ws_schemas.py", 1, 34))

H2("2.4 Bi-directional, multi-client behaviour")
P("Two student browsers and one librarian browser were driven by Playwright against the HTTPS server (wss on the same certificate). The log shows the measured behaviour; the screenshots show the same moments on screen.")
CODE(log("browser_lab8.txt", None, "NETWORK OUTAGE", 14))
IMG(E + "w1_admin_live.png", 15.5); CAP("Figure 1: Librarian dashboard. The badge shows Live and the feed lists check-ins, a student report and the announcement without any page reload.")
IMG(E + "w2_student_live.png", 15.5); CAP("Figure 2: Student page. The live box shows the librarian's announcement; the header badge is green.")

H2("2.5 Heartbeat and half-open connections")
P("A browser that loses power or leaves Wi-Fi range never sends a close frame. The server would keep its socket forever (a half-open connection). The server therefore sends a WebSocket Ping control frame every interval and waits for the Pong, which browsers answer automatically. No Pong within the timeout means the server aborts the transport and removes the client from its rooms.")
LISTING_TITLE("Listing 4: server heartbeat task (app/ws_server.py)")
CODE(lines(A + "ws_server.py", "async def heartbeat", "def _err"))
P("Production defaults are 25 s interval and 10 s timeout. For the tests they were shortened (3 s and 2 s) so that the result could be seen in seconds; this is stated clearly because the numbers below would otherwise look unrealistic.")
CODE(log("ws_stress_log.txt", None, None, 14))
CODE("Heartbeat counters at the end of the run:  PING=373  PONG=363  EVICT=10\n" + "\n".join(l for l in open(E + "ws_heartbeat_log.txt").read().split("\n") if "EVICT" in l)[:760])
TAB([["Test", "Result"],
 ["120 students + 1 librarian connected together", "0.13 s; hello latency p50 75 ms, p95 103 ms"],
 ["One announcement to 120 clients", "120 of 120 received, p50 4.5 ms, maximum 8.6 ms"],
 ["Burst of 100 persisted announcements", "12,000 of 12,000 deliveries, none lost"],
 ["10 half-open clients that never answer a Ping", "All 10 evicted about 5.1 s after connecting; the 120 healthy clients stayed"],
 ["300 connect/close cycles", "Memory about 47 MB before and after; open file descriptors returned to the idle level (no leak)"]], widths=[7.2, 8.6], size=9.5)

H2("2.6 Resilient client: status, exponential backoff with jitter, replay")
P("When the network drops, thousands of clients retrying at the same instant can overload a server that has just restarted. The client therefore waits for an increasing time, ceiling 1, 2, 4, 8, 16 and 30 seconds (cap), and chooses a random wait between 50% and 100% of that ceiling (equal jitter). A status badge shows Connected, Reconnecting in N s, or Offline, and the page falls back to normal polling only while the socket is down. After every reconnect the client sends sync with the last event id it saw and the server replays what was missed (only events the client may see, never other users' private events).")
LISTING_TITLE("Listing 5: backoff calculation (static/js/live.js)")
CODE(grab(A + "static/js/live.js", 20, 8))
P("Test 1: the network was cut for the three browsers (a TCP proxy dropped all sockets). While student 2 was offline the librarian posted an announcement over plain HTTP, and the system generated a private away warning for that student. After the network returned, student 2 received both missed items.")
CODE(log("browser_lab8.txt", "NETWORK OUTAGE", "=== SERVER RESTART", 9))
IMG(E + "w5_reconnecting.png", 15.5); CAP("Figure 3: During the outage the badge reads Reconnecting with a countdown.")
IMG(E + "w4_student2_caught_up.png", 15.5); CAP("Figure 4: After reconnection the feed shows 'Caught up: 2 missed update(s)' with the private warning and the announcement.")
P("Test 2: the server process itself was killed for 22 seconds. The browser console shows the backoff ceilings doubling and then the successful reconnection:")
CODE(log("client_backoff_console.txt", None, None, 16))

H2("2.7 Automated tests")
P("The file tests/test_ws.py has 17 tests that start a real server and connect with real WebSocket clients: handshake rejections (no cookie, tampered cookie, foreign Origin, wrong path, connection cap), room isolation, schema accept and reject, close codes 1008, 1003 and 1009, student cannot announce, a browser holding both a librarian and a student cookie gets the role its page asks for (never a role it has no valid login for), replay after reconnect, an SQL-injection-looking message stored only as data, report delivery to the librarian, and heartbeat survival and eviction. All 17 pass together with the 19 security tests from Lab 6 (36 tests, 0 failures: python -W ignore -m unittest tests.test_ws tests.test_security).")
H2("2.8 Limits and honest notes (Part A)")
B("The real-time tier uses the SQLite pilot database. The PostgreSQL tier from Lab 7 was kept separate and was not required for this lab.")
B("The network outage in Test 1 was produced with a TCP proxy between browser and server, not with a real radio drop. The server-kill test (Test 2) is closer to a real outage.")
B("Heartbeat evidence used shortened timings (3 s/2 s and 10 s/5 s). The production values are 25 s and 10 s.")
B("MU_IGNORE_HOURS=1 is a development-only switch (it works only when APP_ENV=development). It stops the closing-time auto-checkout from interfering with tests run at night.")
B("WebRTC was discussed but not implemented; WebSocket was chosen for the reasons in section 1.1.")
B("Rooms and the connection list live in the memory of one process.")
H2("2.9 Conclusion (Part A) and scaling challenge")
P("The library now behaves as a live system. A check-in reached the librarian's screen 4 to 18 ms after the HTTP response, a private message reached only its owner, a client that disappears is removed within one heartbeat cycle, and a client that was offline catches up on reconnect. Authenticating during the handshake was the most important decision: unauthenticated traffic is rejected by the HTTP layer before any WebSocket code runs, and the Origin check closes the hijacking route.")
P("The main scaling challenge is that WebSocket connections are stateful. Because the hub is in one process, a second server would not know about the sockets on the first. The usual solution is a publish/subscribe backplane (for example Redis) so that each instance forwards events to its own sockets, plus sticky routing or a reconnect-friendly client (which we already have) so that a user can land on any instance. Because every persisted event has an increasing id, the replay logic would carry over unchanged. A single instance comfortably served 121 connections in the stress test; for a campus library this is far above the seat capacity of 120, but a university-wide service would need the backplane.")

# ---------------- Part B ----------------
doc.add_page_break()
H1("3. Part B (Lab 9): Web performance optimisation")
H2("3.1 Method")
P("Performance was measured before changing anything. The frozen copy app_baseline is the application with Lab 8 and no Lab 9 change. Lighthouse 13 ran three times per page with the mobile defaults (simulated Slow 4G, 4x CPU slowdown); the median is reported and the three runs agreed closely (for example 2281.97, 2281.31 and 2281.20 ms). The student page (/) and the librarian dashboard (/admin, sent with a valid signed session cookie) were audited. A second tool, a Playwright probe with Chrome network throttling (1.6 Mbps, 150 ms round trip) and 4x CPU, measured real LCP, CLS and an approximate INP from the Event Timing API, because Lighthouse in navigation mode does not report INP. Core Web Vitals targets: LCP 2.5 s or less, CLS 0.1 or less, INP 200 ms or less (web.dev).")
H2("3.2 Baseline findings")
TAB([["Finding", "Evidence", "Why it hurts"],
 ["The student HTML was 190 KB", "document 194,555 B uncompressed; two copies of the crest PNG and the hero JPEG were embedded as base64 text inside it", "The browser cannot show anything until the whole document arrives; base64 is 33% larger than the file and cannot be cached or compressed away"],
 ["Nothing was compressed or cached", "Repeat visit transferred 191.8 KB again (probe)", "Every visit pays the full cost"],
 ["Render-blocking resources", "Lighthouse render-blocking insight: 530 ms (student), 1,410 ms (admin): Google Fonts CSS and a blocking Chart.js script", "The first paint waits for third-party CSS and a 205 KB script"],
 ["Chart.js loaded up front", "205,125 B; unused-javascript est. 85 KiB", "Cost paid before any chart is drawn"],
 ["Unindexed dashboard queries", "Cold get_stats 33 ms and get_chart_data 82 ms on 100,000 rows", "Slow server response when history grows"]], widths=[4.0, 6.2, 5.6], size=9)
H2("3.2.1 Baseline Lighthouse numbers (median of 3)")
TAB([["Metric", "Student /", "Admin /admin"],
 ["Performance score", "96", "91"], ["First Contentful Paint", "2,281 ms", "2,423 ms"], ["Largest Contentful Paint", "2,281 ms", "2,976 ms (above the 2.5 s target)"],
 ["Total Blocking Time", "0 ms", "84 ms"], ["Cumulative Layout Shift", "0", "0.001"], ["Server response (TTFB)", "2 ms", "2 ms"], ["Transferred", "199.7 KB in 7 requests", "241.4 KB in 10 requests"]], widths=[5.4, 5.2, 5.2], size=9.5)

H2("3.3 Image optimisation")
P("The three base64 images were extracted from the HTML into files and converted with Pillow to WebP and AVIF in the sizes actually displayed (the crest is shown at 96 px, so 96 and 192 px versions serve 1x and 2x screens). The hero picture changed from a CSS background to a picture element with AVIF first, WebP as fallback, two widths in srcset, explicit width and height (so the layout does not move), fetchpriority high and a preload link because it is the LCP element. There are no images below the first screen, so loading=lazy was not needed; it would have delayed the hero and hurt LCP.")
LISTING_TITLE("Listing 6: hero and crest markup (templates/index.html)")
CODE('<link rel="preload" as="image" type="image/avif" imagesrcset="/static/img/hero-400.avif 400w, /static/img/hero-738.avif 738w"\n      imagesizes="(max-width:600px) 100vw, 738px" fetchpriority="high">\n...\n<picture><source type="image/avif" srcset="/static/img/hero-400.avif 400w, /static/img/hero-738.avif 738w" sizes="(max-width:600px) 100vw, 738px">\n  <img class="hero-bg" src="/static/img/hero-738.webp" srcset="/static/img/hero-400.webp 400w, /static/img/hero-738.webp 738w"\n       sizes="(max-width:600px) 100vw, 738px" width="738" height="415" fetchpriority="high" decoding="async" alt=""/></picture>')
TAB([["Image", "Before", "After (AVIF / WebP)"],
 ["Hero (738 px)", "69,249 B JPEG, about 92 KB as base64 text inside the HTML", "36,951 B AVIF; 69,210 B WebP fallback; 9,865 B AVIF for phones (400 px)"],
 ["Crest, shown at 96 px", "18,493 B PNG as base64, embedded twice (about 49 KB of HTML)", "2,518 B WebP / 1,873 B AVIF at 96 px; 4.3 KB AVIF at 192 px for 2x screens"]], widths=[3.4, 6.2, 6.2], size=9.5)

H2("3.4 Fonts")
P("The page requested Google Fonts CSS from a third-party domain, which blocks rendering and needs extra connections. The fonts were self-hosted from the @fontsource-variable packages (Inter, Playfair Display, Source Sans 3; Latin subset only; WOFF2). A variable font file holds all weights, so Inter went from four to five static files to one 48 KB file. font-display: swap shows text at once in a fallback face and swaps when the font arrives. The two fonts used above the fold are preloaded. Because no outside host is needed any more, the Content Security Policy was tightened to font-src 'self' and the googleapis allowance was removed from style-src.")
H2("3.5 JavaScript and CSS: bundling, tree-shaking and splitting")
P("The 17 KB of inline CSS and 20 KB of inline JavaScript were moved into static/src. The script build.mjs (esbuild) minifies them, tree-shakes unused code, writes content-hashed names such as index-U3FIG3KZ.js and records them in manifest.json. A Jinja helper asset('index.js') puts the hashed URL in the template. The module scripts are deferred by default, so they do not block the first paint. The admin page no longer loads the 205 KB Chart.js file in the head: it is imported only when the charts are drawn, as a separate chunk containing only the bar and line controllers that the dashboard uses.")
LISTING_TITLE("Listing 7: lazy chart chunk (static/src/chart-lazy.js and the call in admin.js)")
CODE(open(A + "static/src/chart-lazy.js").read().rstrip() + "\n\n// admin.js\nlet Chart=null;\nasync function loadCharts(){\n  const r=await fetch('/api/admin/chart_data',{cache:'no-store'});const d=await r.json();\n  if(!Chart){Chart=(await import('./chart-lazy.js')).Chart;}")
CODE("Build output (node build.mjs):\n" + "\n".join(["   14899 B  static/dist/index-U3FIG3KZ.js", "    9339 B  static/dist/admin-UG6FSOUR.js", "    4461 B  static/dist/live-N4SVCGBY.js", "  180651 B  static/dist/chunks/chart-lazy-EKBP65W2.js   (loaded only on the dashboard)", "   17858 B  index-643ED94F.css   8030 B admin-1994BCC5.css   674 B fonts-27895336.css"]))
P("Honest note: tree-shaking reduced Chart.js from 205 KB to 181 KB, a modest saving, because the library's core is large. The real gain on the dashboard comes from moving it out of the critical path and compressing it (55 KB with Brotli).")

H2("3.6 Cache-Control, ETag and compression")
P("All delivery rules are in one file, app/perf.py, so they can be audited in one place. The table summarises the policy and the reason for each rule.")
TAB([["Resource", "Cache-Control", "Why"],
 ["/static/dist/* and fonts (names contain a hash or a version)", "public, max-age=31536000, immutable", "The content can never change under the same name; a new build gets a new name"],
 ["Images, other static files", "public, max-age=3600, stale-while-revalidate=86400 (+ ETag, 304)", "Names are not hashed, so a short life with revalidation"],
 ["Public HTML (/)", "public, no-cache + ETag", "Always ask, but a 304 sends no body when unchanged"],
 ["/api/occupancy, /api/seats/*", "public, max-age=0, must-revalidate, s-maxage=5, stale-while-revalidate=30", "Browser always revalidates (so a student sees their own check-in at once); a shared cache or CDN may hold it for 5 s"],
 ["/api/active_sessions", "private, no-cache + Vary: Cookie", "Contains a per-caller 'this is you' flag"],
 ["/admin, /api/admin/*, /portal, login, errors", "private, no-store", "Authenticated or personal data must never be stored by a cache"]], widths=[5.4, 5.6, 4.8], size=9)
LISTING_TITLE("Listing 8: the policy function (app/perf.py)")
CODE(lines(A + "perf.py", "def policy(path, method, status):", "# ── 2."))
P("Compression: responses of text type and at least 500 bytes are compressed with Brotli when the browser accepts it, otherwise gzip, and the header Vary: Accept-Encoding is set so that a shared cache stores each version separately. The ETag is computed from the uncompressed body so it identifies the content, not the encoding. Static files are compressed once at quality 11 and kept in memory; dynamic responses use a faster quality. Already-compressed formats (AVIF, WebP, WOFF2) are left alone.")
CODE(log("delivery_headers.txt", None, "### 5.", 41))
CODE(log("delivery_headers.txt", "### 5.", "### 8.", 22))
LISTING_TITLE("Table: bytes on the wire per resource (evidence/payload_table.txt)")
TAB([["Resource", "Raw", "gzip", "Brotli", "Brotli saving"],
 ["HTML page /", "15,657", "4,314", "3,967", "75%"], ["index.js", "14,899", "5,197", "4,477", "70%"], ["admin.js", "9,339", "3,420", "2,927", "69%"], ["live.js", "4,461", "1,862", "1,655", "63%"],
 ["chart chunk", "180,651", "63,320", "54,940", "70%"], ["index.css", "17,858", "4,350", "3,797", "79%"], ["admin.css", "8,030", "2,142", "1,837", "77%"]], widths=[4.4, 2.8, 2.8, 2.8, 3.0], size=9.5)

H2("3.7 Database and server response time")
P("The dashboard answers are aggregates over the whole history table. Three changes were made: indexes on check_out_time, check_in_time and floor; date filters rewritten as ranges (check_in_time >= today AND < tomorrow) so that an index can be used instead of wrapping every row in DATE(); and a five-second cache for the two aggregate queries that is cleared by any check-in or check-out event. The history endpoint became paginated (page and page_size, at most 200). The benchmark used 100,000 generated rows in a copy of the database, the median of 15 cold calls.")
TAB([["Query", "Before (ms)", "After (ms)"], ["get_stats, cold", "32.7", "7.2"], ["get_chart_data, cold", "82.2", "38.9"], ["History page", "9.1 (200 rows)", "0.26 (50 rows)"], ["get_stats, cache hit", "n/a", "0.0002"]], widths=[6.0, 4.9, 4.9], size=9.5)
P("The history comparison is not like for like (200 rows before, 50 after), because pagination changes the page size; it shows what the user now receives. get_chart_data stays the slowest because grouping by hour must still read every row; with a larger history, a pre-computed summary table would be the next step.")

H2("3.8 Results")
IMG(E + "fig_lighthouse.png", 16.2); CAP("Figure 5: Lighthouse medians (3 runs), before and after, mobile profile.")
TAB([["Metric (Lighthouse, median of 3)", "Student before", "Student after", "Admin before", "Admin after"],
 ["Performance score", "96", "99", "91", "99"], ["First Contentful Paint (ms)", "2,281", "792", "2,423", "760"], ["Largest Contentful Paint (ms)", "2,281", "2,078", "2,976", "2,081"],
 ["Total Blocking Time (ms)", "0", "33", "84", "108"], ["Cumulative Layout Shift", "0", "0", "0.001", "0.001"], ["HTML document (KB)", "190.0", "4.7", "25.3", "2.5"], ["Transferred (KB)", "199.7", "173.3", "241.4", "139.5"]], widths=[5.2, 2.6, 2.6, 2.7, 2.7], size=9)
P("Reading the table honestly: the student page already scored 96, so the score moved little. The clear gains are First Contentful Paint (2.3 s to 0.8 s, because the HTML shrank from 190 KB to 4.7 KB and nothing blocks the first paint), the admin LCP (2.98 s, above the 2.5 s target, to 2.08 s), and the admin transfer (241 KB to 140 KB). The student LCP improved less (2.28 s to 2.08 s) because the LCP element is the 37 KB hero image, which must still cross the simulated slow link. Total Blocking Time rose slightly on both pages (0 to 33 ms, 84 to 108 ms) because the browser now runs the module and chart code as separate steps; both are far below the 200 ms 'good' limit and the run-to-run spread was larger than the change (admin runs: 83, 108 and 138 ms). Lighthouse still reports a cache insight of 36 KiB for the unhashed images (1 hour life); hashing the image names would remove it.")
TAB([["Playwright probe (1.6 Mbps, 150 ms, 4x CPU)", "Before", "After"],
 ["Student first visit: transferred", "198.7 KB (5 requests)", "172.4 KB (11 requests, includes the fonts the baseline could not download here)"],
 ["Student first visit: LCP", "872 ms", "1,128 ms"],
 ["Student repeat visit: transferred", "191.8 KB", "1.6 KB (all assets from cache)"],
 ["Student repeat visit: LCP", "852 ms", "416 ms"],
 ["Admin warm load: LCP / transferred", "1,028 ms / 33 KB (Chart.js not cached)", "1,008 ms / 6.9 KB"],
 ["Interaction (INP approx., 25 interactions)", "72 ms", "48 ms"],
 ["CLS / console errors", "0 / 1 (blocked Google Fonts)", "0 / 0"]], widths=[6.2, 4.8, 4.8], size=9)
IMG(E + "fig_repeat.png", 9.5); CAP("Figure 6: Transfer on the second visit of the student page: 191.8 KB before, 1.6 KB after.")
P("Important caveat: the sandbox where the tests were run blocks fonts.googleapis.com, so the baseline did not really download its web fonts. On a real network the baseline would be slower than measured here, and the first-visit LCP in the probe (872 ms before, 1,128 ms after) is therefore not a fair comparison: the 'after' page downloads 108 KB of fonts that the 'before' page failed to fetch. The repeat-visit and HTML-size results do not depend on this. The server was local, so TTFB was about 2 to 7 ms in both versions; on a real server the Brotli and caching changes matter more than these numbers suggest. Chrome does not cache responses that come over a connection with a certificate error, so the cache tests used plain HTTP on localhost.")
IMG(E + "opt_student_mobile.png", 6.2); CAP("Figure 7: The optimised student page on a 412 px wide phone viewport: hero image, self-hosted fonts and the crest render correctly.")

H2("3.9 CDN, range requests and media")
P("The Cache-Control header on the shared JSON routes already contains s-maxage, which is the instruction a CDN or reverse proxy obeys. A sample nginx configuration (deploy/nginx-cdn-cache.conf) caches /static for a year (storing Brotli and gzip variants separately), caches the occupancy and seat routes for the s-maxage time with stale-while-revalidate, passes the WebSocket path straight through, and never caches anything else. That file was not run in this lab (nginx is not installed in the test environment), so it is an untested sample. Range requests work on static files (a request for bytes 0 to 99 of the hero image returned 206 Partial Content with Content-Range: bytes 0-99/69210, see section 3.6). The application contains no audio or video, so streaming optimisation was not applicable.")
H2("3.10 Limits and honest notes (Part B)")
B("All timings come from one laptop-class sandbox with a local server, Lighthouse simulation and a headless browser. They show the direction and size of each change; they are not field data from real students.")
B("Lighthouse scores vary between runs; three runs were taken for each page and the spread is given where it matters.")
B("The student page was already fast; the optimisation matters most for the dashboard, for repeat visits and for slow networks.")
B("No CDN or nginx was actually deployed.")
B("The WebSocket events refresh data with fresh requests, so the five-second public cache cannot show a student stale seat states after their own action (browsers always revalidate).")
H2("3.11 Conclusion (Part B)")
P("Measuring first changed the plan: the biggest cost was not JavaScript but a 190 KB HTML document carrying images as text, with a third-party font request and an eager 205 KB chart library on top. Moving the images to AVIF/WebP files, self-hosting variable fonts, splitting and hashing the bundles, and describing each response with the right cache policy cut first paint by about two thirds, reduced the dashboard's LCP from 2.98 s to 2.08 s, and made the repeat visit almost free (1.6 KB). The result stays safe: the Content Security Policy became stricter, authenticated routes are no-store, and all 36 tests still pass.")

# ---------------- references ----------------
H1("4. References")
for r in ["Fette, I. and Melnikov, A. (2011) RFC 6455: The WebSocket Protocol. IETF. https://www.rfc-editor.org/rfc/rfc6455",
          "W3C (2021) WebRTC 1.0: Real-Time Communication Between Browsers. https://www.w3.org/TR/webrtc/",
          "Mozilla Developer Network (n.d.) WebSockets API; Content Security Policy (CSP); Cache-Control; ETag. https://developer.mozilla.org/",
          "Fielding, R., Nottingham, M. and Reschke, J. (2022) RFC 9111: HTTP Caching. IETF. https://www.rfc-editor.org/rfc/rfc9111",
          "Nottingham, M. (2017) RFC 8246: HTTP Immutable Responses; (2010) RFC 5861: stale-while-revalidate. IETF.",
          "Google (n.d.) Web Vitals (LCP, CLS, INP). web.dev. https://web.dev/vitals/",
          "Google Chrome team (n.d.) Lighthouse performance scoring and insights. https://developer.chrome.com/docs/lighthouse/",
          "Evan Wallace (n.d.) esbuild documentation: bundling, splitting, tree shaking. https://esbuild.github.io/",
          "Fontsource (n.d.) Self-host Open Source fonts in neat NPM packages. https://fontsource.org/",
          "Python websockets documentation, version 17 (asyncio server, process_request, ping/pong). https://websockets.readthedocs.io/",
          "JSON Schema (2020) Draft 2020-12 specification. https://json-schema.org/",
          "OWASP (n.d.) Cross-Site WebSocket Hijacking and WebSocket Security Cheat Sheet. https://cheatsheetseries.owasp.org/",
          "Brotli Authors / Alakuijala, J. and Szabadka, Z. (2016) RFC 7932: Brotli Compressed Data Format. IETF."]:
    B(r)

H1("5. Declaration on the use of Artificial Intelligence")
P("I used an AI assistant (Claude, by Anthropic) to help plan, write and test the code for these labs and to draft this report. I ran the application and the tests, checked the evidence files and screenshots against the running system, and I take responsibility for the content and can explain it. The measurements in this report come from the tools named in section 3.1 and from the logs in the archive, not from the AI's memory. The references were consulted for the concepts they describe. No text was copied from other students or sources without citation.")
TAB([["Name", "Student number", "Date"], ["Dennis Sampa", "202302571", "19 November 2026"]], widths=[6, 5, 4.8], size=10.5)
out = sys.argv[2] if len(sys.argv) > 2 else "/home/claude/lab89/report/ICT461_LAB_8&9_202302571.docx"
doc.save(out); print("saved", out)
